import hashlib,json,pathlib,subprocess
root=pathlib.Path(__file__).parent;rawp=(root/'search-page1-response.json').read_bytes();page=json.loads(rawp);ledger=json.loads((root/'page1-identity-ledger.json').read_bytes());dups={x['repo_issue'] for x in ledger['duplicate_rows']};ids=[x['node_id'] for x in page['items'] if f"pallets/flask#{x['number']}" not in dups]
query=f'''query K40FlaskB01Page1ClosedEventsCorrection1 {{
  nodes(ids: {json.dumps(ids,separators=(',',':'))}) {{
    __typename
    ... on Issue {{
      number
      timelineItems(first: 20, itemTypes: [CLOSED_EVENT]) {{
        nodes {{
          __typename
          ... on ClosedEvent {{
            id
            createdAt
            closer {{
              __typename
              ... on PullRequest {{
                number
                state
                mergedAt
                repository {{ nameWithOwner }}
                mergeCommit {{
                  oid
                  parents(first: 2) {{ nodes {{ oid tree {{ oid }} }} }}
                }}
              }}
            }}
          }}
        }}
      }}
    }}
  }}
}}
'''
qfile=root/'closed-event-page1-query-correction-1.graphql';qfile.write_bytes(query.encode('utf-8'));resp='closed-event-page1-correction-1-response.json';err='closed-event-page1-correction-1-stderr.bin';argv=['gh','api','graphql','--method','POST','-F',f'query=@{qfile}']
req={'operation':'one corrected GraphQL syntax attempt after locally generated page1 query parse failure','method':'POST','endpoint':'https://api.github.com/graphql','unique_issue_node_ids':len(ids),'search_response_sha256':hashlib.sha256(rawp).hexdigest(),'prior_failed_request':'closed-event-page1-request.json','prior_error_response':'closed-event-page1-response.json','prior_error_stderr':'closed-event-page1-stderr.bin','query_file':qfile.name,'argv':argv,'output_file':resp,'stderr_file':err,'saved_before_call':True,'fields':['issue number','ClosedEvent id/time','closer type','PR number/state/mergedAt/repository','mergeCommit oid/first-parent/tree'],'excluded_fields':['PR body','PR diff','fix','comments','test bodies']}
(root/'closed-event-page1-request-correction-1.json').write_bytes(json.dumps(req,ensure_ascii=False,indent=2).encode('utf-8'))
with (root/resp).open('wb') as f:p=subprocess.run(argv,stdout=f,stderr=subprocess.PIPE)
(root/err).write_bytes(p.stderr);rawc=(root/resp).read_bytes();out={'exit_code':p.returncode,'node_ids':len(ids),'response_bytes':len(rawc),'response_sha256':hashlib.sha256(rawc).hexdigest(),'stderr_bytes':len(p.stderr)}
if p.returncode: out['stderr_utf8_replace']=p.stderr.decode('utf-8','replace')
print(json.dumps(out,ensure_ascii=False));raise SystemExit(p.returncode)
