import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path(__file__).parent; page_no=int(sys.argv[1]); repo='pallets/flask'; raw=(root/f'search-page{page_no}-response.json').read_bytes(); page=json.loads(raw); catalog=json.loads(pathlib.Path('attachments/k68-catalog-v7.json').read_bytes())
known={((r.get('identity') or {}).get('repo_issue') or r.get('task_id')) for r in catalog.get('records',[])}; prior=set()
for p in range(1,page_no):
 f=pathlib.Path(f'batch-python-flask-20261103-b01/search-page{p}-response.json')
 if f.exists(): prior.update(f'{repo}#{x["number"]}' for x in json.loads(f.read_bytes()).get('items',[]))
seen=set();new=[];dups=[];bdir=root/'issue-bodies';bdir.mkdir(exist_ok=True)
for x in page.get('items',[]):
 key=f'{repo}#{x["number"]}'; reasons=[]
 if key in known: reasons.append('current-K68-v7-exact-identity')
 if key in prior: reasons.append('previously-consumed-batch-page-exact-identity')
 if key in seen: reasons.append('duplicate-within-search-page')
 seen.add(key)
 if reasons: dups.append({'repo_issue':key,'skip_reasons':reasons});continue
 body=x.get('body'); bb=b'' if body is None else body.encode('utf-8'); dest=bdir/f'flask-{x["number"]}.txt';dest.write_bytes(bb)
 if dest.read_bytes()!=bb: raise RuntimeError('body byte mismatch '+key)
 new.append({'stable_id':f'pallets-flask-{x["number"]}-metadata-b01','repo':repo,'issue_number':x['number'],'repo_issue':key,'title':x.get('title'),'issue_url':x.get('html_url'),'state':x.get('state'),'created_at':x.get('created_at'),'closed_at':x.get('closed_at'),'body_file':f'issue-bodies/{dest.name}','body_was_null':body is None,'body_utf8_bytes':len(bb),'body_sha256':hashlib.sha256(bb).hexdigest(),'body_equals_direct_utf8_encoding':True,'dedup_key':key+'|base=UNKNOWN|source=UNKNOWN','source_role':'UNKNOWN','split':'UNASSIGNED','family':'UNKNOWN','actor_visible':False,'trusted_acceptance':False,'purpose_authorization':'NOT_GRANTED','training_release':'BLOCKED','environment':'NOT_ASSESSED','deployment':'NOT_ASSESSED','disposition':'NEW_METADATA_PENDING_CLOSURE_SCREEN'})
idledger={'schema':'k40-page-identity-dedup/2','repo':repo,'page':page_no,'catalog_attachment_id':'01a1a0cf-a37f-7c44-a468-d59ded39eae1','catalog_sha256':hashlib.sha256(pathlib.Path('attachments/k68-catalog-v7.json').read_bytes()).hexdigest(),'search_response_sha256':hashlib.sha256(raw).hexdigest(),'search_response_bytes':len(raw),'identities_returned':len(page.get('items',[])),'unique_new_identities':len(new),'duplicates_skipped':len(dups),'duplicate_rows':dups,'new_rows':new}
(root/f'page{page_no}-identity-ledger.json').write_bytes(json.dumps(idledger,ensure_ascii=False,indent=2).encode('utf-8'))
ids=[x['node_id'] for x in page.get('items',[]) if f'{repo}#{x["number"]}' not in {d['repo_issue'] for d in dups}]
if not ids:
 print(json.dumps({'page':page_no,'returned':len(page.get('items',[])),'unique':len(new),'duplicates':len(dups),'closure_query':'NOT_ISSUED_NO_UNIQUE_IDS'},ensure_ascii=False));sys.exit(0)
query=f'''query K40FlaskB01Page{page_no}ClosedEvents {{
  nodes(ids: {json.dumps(ids,separators=(',',':'))}) {{
    __typename
    ... on Issue {{
      number
      timelineItems(first: 20, itemTypes: [CLOSED_EVENT]) {{
        nodes {{
          __typename
          ... on ClosedEvent {{
            id
            createdAt
            closer {{
              __typename
              ... on PullRequest {{
                number
                state
                mergedAt
                repository {{ nameWithOwner }}
                mergeCommit {{
                  oid
                  parents(first: 2) {{
                    nodes {{ oid tree {{ oid }} }}
                  }}
                }}
              }}
            }}
          }}
        }}
      }}
    }}
  }}
}}
'''
qfile=root/f'closed-event-page{page_no}-query.graphql';qfile.write_bytes(query.encode('utf-8'));resp=f'closed-event-page{page_no}-response.json';err=f'closed-event-page{page_no}-stderr.bin';argv=['gh','api','graphql','--method','POST','-F',f'query=@{qfile}']
req={'operation':f'batched ClosedEvent-only GraphQL query for unique pallets/flask page{page_no} IDs','method':'POST','endpoint':'https://api.github.com/graphql','unique_issue_node_ids':len(ids),'search_response_sha256':hashlib.sha256(raw).hexdigest(),'query_file':qfile.name,'argv':argv,'output_file':resp,'stderr_file':err,'saved_before_call':True,'fields':['issue number','ClosedEvent id/time','closer type','PR number/state/mergedAt/repository','mergeCommit oid/first-parent/tree'],'excluded_fields':['PR body','PR diff','fix','comments','test bodies']}
(root/f'closed-event-page{page_no}-request.json').write_bytes(json.dumps(req,ensure_ascii=False,indent=2).encode('utf-8'))
with (root/resp).open('wb') as f:p=subprocess.run(argv,stdout=f,stderr=subprocess.PIPE)
(root/err).write_bytes(p.stderr);rawc=(root/resp).read_bytes();out={'page':page_no,'returned':len(page.get('items',[])),'unique':len(new),'duplicates':len(dups),'node_ids':len(ids),'search_sha256':hashlib.sha256(raw).hexdigest(),'graphql_exit':p.returncode,'graphql_response_bytes':len(rawc),'graphql_response_sha256':hashlib.sha256(rawc).hexdigest(),'stderr_bytes':len(p.stderr)}
if p.returncode: out['stderr_utf8_replace']=p.stderr.decode('utf-8','replace');(root/f'closed-event-page{page_no}-failure-summary.json').write_bytes(json.dumps(out,ensure_ascii=False,indent=2).encode('utf-8'))
print(json.dumps(out,ensure_ascii=False));sys.exit(p.returncode)
