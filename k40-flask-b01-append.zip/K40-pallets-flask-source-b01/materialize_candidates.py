import ast,hashlib,json,pathlib,re,subprocess,sys,tarfile,tomllib
root=pathlib.Path(__file__).parent;pno=int(sys.argv[1]);numbers=[int(x) for x in sys.argv[2:]];page=json.loads((root/f'search-page{pno}-response.json').read_bytes());by={x['number']:x for x in page['items']};screen=json.loads((root/f'closed-event-page{pno}-screening.json').read_bytes());cl={x['issue_number']:x for x in screen['rows']}
reasons={5258:'Issue body reports Flask.url_for raising TypeError for a keyword argument named self despite no documented precondition; direct concrete runtime behavior with an in-body reproducer and no implementation fix included in the selected task prompt.'}
for n in numbers:
 if n not in by or n not in cl: raise RuntimeError(f'missing issue/closure {n}')
 c=cl[n]
 if not c.get('same_repo_merged_closer_present') or c.get('timestamp_status')!='MATCH' or not c.get('first_parent_base') or not c.get('first_parent_tree'): raise RuntimeError(f'closure gate failed {n}')
 issue=by[n];base=c['first_parent_base'];folder=root/'candidates'/f'pallets-flask-{n}-source-b01';folder.mkdir(parents=True,exist_ok=True);body=issue.get('body');bb=b'' if body is None else body.encode('utf-8');(folder/'issue-body.txt').write_bytes(bb)
 if (folder/'issue-body.txt').read_bytes()!=bb: raise RuntimeError('body bytes mismatch')
 url=f'https://codeload.github.com/pallets/flask/tar.gz/{base}';archive=folder/'source.tar.gz'
 attempts=[]; prior=sorted(folder.glob('codeload-attempt-*-http-status.txt'));attempt_no=len(prior)+1
 if attempt_no>2: raise RuntimeError('refusing more than two recorded codeload attempts')
 statusfile=folder/f'codeload-attempt-{attempt_no}-http-status.txt';errfile=folder/f'codeload-attempt-{attempt_no}-stderr.bin';reqfile=folder/f'codeload-attempt-{attempt_no}-request.json'
 argv=['curl.exe','--location','--fail','--silent','--show-error','-o',str(archive),'--write-out','%{http_code}',url]
 req={'attempt':attempt_no,'method':'GET','url':url,'host':'codeload.github.com','repo':'pallets/flask','ref':base,'representation':'official codeload tar.gz','output_file':'source.tar.gz','status_file':statusfile.name,'stderr_file':errfile.name,'argv':argv,'retry_count':0,'saved_before_call':True}
 reqfile.write_bytes(json.dumps(req,ensure_ascii=False,indent=2).encode('utf-8'))
 p=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE);statusfile.write_bytes(p.stdout);errfile.write_bytes(p.stderr)
 attempt={'attempt':attempt_no,'exit_code':p.returncode,'http_status':p.stdout.decode('ascii','replace'),'stderr_file':errfile.name,'stderr_bytes':len(p.stderr),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest(),'request_file':reqfile.name}
 if p.returncode or not archive.exists():
  (folder/f'codeload-attempt-{attempt_no}-result.json').write_bytes(json.dumps(attempt,ensure_ascii=False,indent=2).encode('utf-8'));print(json.dumps({'issue':n,'stage':'codeload','attempt':attempt_no,**attempt,'stderr_utf8_replace':p.stderr.decode('utf-8','replace')},ensure_ascii=True));sys.exit(p.returncode or 1)
 with tarfile.open(archive,'r:gz') as tf: members=[m.name for m in tf.getmembers() if m.isfile()]
 (folder/'archive-members.txt').write_bytes(('\n'.join(members)+'\n').encode('utf-8'));top=members[0].split('/')[0];license_names=[m for m in members if re.fullmatch(re.escape(top)+r'/LICENSE(?:\.[^/]*)?',m)];licrows=[]
 for m in license_names:
  with tarfile.open(archive,'r:gz') as tf: raw=tf.extractfile(m).read()
  fn=m.rsplit('/',1)[-1];(folder/fn).write_bytes(raw);licrows.append({'archive_member':m,'file':fn,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 if not licrows: raise RuntimeError(f'historical LICENSE absent {n}')
 deps=[];depfiles=[]
 with tarfile.open(archive,'r:gz') as tf:
  for member in (top+'/pyproject.toml',top+'/setup.py'):
   try: raw=tf.extractfile(member).read()
   except (KeyError,AttributeError): continue
   fn=member.rsplit('/',1)[-1];(folder/fn).write_bytes(raw);depfiles.append({'archive_member':member,'file':fn,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
   if fn=='pyproject.toml':
    pd=tomllib.loads(raw.decode('utf-8'));proj=pd.get('project',{})
    for k in ('requires-python','dependencies'):
     if k in proj: deps.append({'file':fn,'field':'project.'+k,'value':proj[k]})
    for k,v in (proj.get('optional-dependencies') or {}).items(): deps.append({'file':fn,'field':'project.optional-dependencies.'+k,'value':v})
   else:
    tree=ast.parse(raw.decode('utf-8'));assign={}
    for nd in ast.walk(tree):
     if isinstance(nd,(ast.Assign,ast.AnnAssign)):
      for t in (nd.targets if isinstance(nd,ast.Assign) else [nd.target]):
       if isinstance(t,ast.Name):
        try: assign[t.id]=ast.literal_eval(nd.value)
        except Exception: pass
    for nd in ast.walk(tree):
     if isinstance(nd,ast.Call):
      for kw in nd.keywords:
       if kw.arg=='install_requires':
        val=assign.get(kw.value.id) if isinstance(kw.value,ast.Name) else None
        if val is None:
         try: val=ast.literal_eval(kw.value)
         except Exception: val='DECLARATION_PRESENT_NOT_STATICALLY_RESOLVED'
        deps.append({'file':fn,'field':'setup.install_requires','value':val})
 tests=[]
 for m in members:
  parts=m.split('/');
  if len(parts)<2 or parts[0]!=top: continue
  rel=parts[1:];name=rel[-1]
  if any(t in {'test','tests','_tests'} for t in rel[:-1]) or name.startswith('test_') or name.endswith('_test.py'): tests.append(m)
 (folder/'test-paths-members-only.txt').write_bytes(('\n'.join(tests)+'\n').encode('utf-8'));(folder/'dependency-declarations.json').write_bytes(json.dumps({'schema':'k40-dependency-evidence/1','base_commit':base,'source_files':depfiles,'declarations':deps,'test_requirements_file_contents':'NOT_READ','environment':'NOT_ASSESSED'},ensure_ascii=False,indent=2).encode('utf-8'))
 ah=hashlib.sha256(archive.read_bytes()).hexdigest();alen=archive.stat().st_size;lic=licrows[0];rsh=hashlib.sha256((root/f'closed-event-page{pno}-response.json').read_bytes()).hexdigest();search_sha=hashlib.sha256((root/f'search-page{pno}-response.json').read_bytes()).hexdigest()
 rec={'schema':'k40-fixed-source-candidate/1','stable_id':f'pallets-flask-{n}-source-b01','repo':'pallets/flask','issue_number':n,'repo_issue':f'pallets/flask#{n}','title':issue['title'],'issue_url':issue['html_url'],'issue_body':{'path':'issue-body.txt','encoding':'UTF-8','bytes':len(bb),'sha256':hashlib.sha256(bb).hexdigest(),'search_response_sha256':search_sha},'source_selection_reason':reasons[n],'closure':{'event_type':'ClosedEvent','event_id':c['closed_event_id'],'event_time':c['event_created_at'],'search_closed_at':c['search_closed_at'],'timestamp_status':c['timestamp_status'],'json_pointer':c['json_pointer'],'raw_response_file':f'../../closed-event-page{pno}-response.json','raw_response_sha256':rsh,'closer_type':c['closer_type'],'closer_repo':c['closer_repo'],'pr_number':c['pr_number'],'pr_state':c['pr_state'],'pr_merged_at':c['pr_merged_at'],'merge_commit':c['merge_commit'],'first_parent_base':base,'first_parent_tree':c['first_parent_tree']},'source':{'ref':base,'base_commit':base,'base_tree':c['first_parent_tree'],'archive_path':'source.tar.gz','archive_sha256':ah,'archive_bytes':alen,'http_status':p.stdout.decode('ascii','replace')},'license_evidence':licrows,'primary_license_sha256':lic['sha256'],'dependencies':'dependency-declarations.json','dependency_source_files':depfiles,'test_path_inventory':'test-paths-members-only.txt','test_path_count':len(tests),'test_adapter_gap':'UNKNOWN; archive member names only; no environment adaptation assessed and tests not run.','dedup_key':f'pallets/flask#{n}|base={base}|source={ah}','family':'UNKNOWN_PENDING_RELATED_REF_REVIEW','split':'UNASSIGNED','source_role':'UNKNOWN','actor_visible':False,'trusted_acceptance':False,'training_release':'BLOCKED','purpose_authorization':'NOT_GRANTED','environment':'NOT_ASSESSED','deployment':'NOT_ASSESSED','old_exposure':'UNKNOWN_PENDING_EXCLUSION_CLEARANCE','content_boundary':'Original issue body is source provenance, not actor prompt. No PR body/diff/fix, test body, hidden evaluation, or linked external POC was fetched/read.'}
 (folder/'source-record.json').write_bytes(json.dumps(rec,ensure_ascii=False,indent=2).encode('utf-8'));print(json.dumps({'issue':n,'base':base,'tree':c['first_parent_tree'],'archive_bytes':alen,'archive_sha256':ah,'license_sha256':lic['sha256'],'test_path_count':len(tests),'dependency_files':depfiles},ensure_ascii=False))
