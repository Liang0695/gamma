import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path(__file__).parent; page=int(sys.argv[1]); repo='pallets/flask'; q=f"repo:{repo} is:issue is:closed created:2019-01-01..2025-12-31"
if page==1:
 req={'operation':'GitHub rate-limit preflight via existing gh client','method':'GET','endpoint':'https://api.github.com/rate_limit','argv':['gh','api','rate_limit'],'output_file':'rate-limit-response.json','stderr_file':'rate-limit-stderr.bin','saved_before_call':True}
 (root/'rate-limit-request.json').write_bytes(json.dumps(req,ensure_ascii=False,indent=2).encode('utf-8'))
 with (root/req['output_file']).open('wb') as f: p=subprocess.run(req['argv'],stdout=f,stderr=subprocess.PIPE)
 (root/req['stderr_file']).write_bytes(p.stderr)
 if p.returncode:
  (root/'rate-limit-failure.json').write_bytes(json.dumps({'exit_code':p.returncode,'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()},indent=2).encode());sys.exit(p.returncode)
argv=['gh','api','--method','GET','search/issues','-f',f'q={q}','-F','per_page=100','-F',f'page={page}','-f','sort=created','-f','order=desc']
req={'operation':'bounded GitHub Search page for new non-pytest source','method':'GET','client':'existing authenticated gh CLI','endpoint':'https://api.github.com/search/issues','repo':repo,'query':q,'per_page':100,'page':page,'sort':'created','order':'desc','argv':argv,'output_file':f'search-page{page}-response.json','stderr_file':f'search-page{page}-stderr.bin','saved_before_call':True}
(root/f'search-page{page}-request.json').write_bytes(json.dumps(req,ensure_ascii=False,indent=2).encode('utf-8'))
with (root/req['output_file']).open('wb') as f: p=subprocess.run(argv,stdout=f,stderr=subprocess.PIPE)
(root/req['stderr_file']).write_bytes(p.stderr);raw=(root/req['output_file']).read_bytes();info={'page':page,'exit_code':p.returncode,'response_bytes':len(raw),'response_sha256':hashlib.sha256(raw).hexdigest(),'stderr_bytes':len(p.stderr)}
if p.returncode:
 info['stderr_sha256']=hashlib.sha256(p.stderr).hexdigest();info['stderr_utf8_replace']=p.stderr.decode('utf-8','replace');(root/f'search-page{page}-failure-summary.json').write_bytes(json.dumps(info,ensure_ascii=False,indent=2).encode('utf-8'));print(json.dumps(info,ensure_ascii=True));sys.exit(p.returncode)
d=json.loads(raw);items=d.get('items',[]);info.update({'repo':repo,'total_count':d.get('total_count'),'items':len(items),'first_issue':items[0].get('number') if items else None,'last_issue':items[-1].get('number') if items else None});print(json.dumps(info,ensure_ascii=False))
