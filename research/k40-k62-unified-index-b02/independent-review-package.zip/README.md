审查结论：有条件通过

## 审查结论：有条件通过

B9、B10、B11 各20条，共60条固定来源链已独立核证；来源证据可追加记账。索引门禁摘要与引用标签尚有应修项，家族/root、用途及训练资格未放行，尚不可据此交付为可用训练题。

### 🔴 阻断问题（0 项）

### 🟡 应修问题（2 项）

1. `evidence/B9/evidence/k62-gate-review.json:k62_v24`，B10/B11同字段，以及输入索引 `manifest.json:gate_snapshot`：门禁原件 SHA 指向错误。
   - 现象 / 触发条件：三批均声明 dedup 摘要 `c74ae60e3346e16939358d7bbf783ec3635c7c7218111490e235ca943edd9511`、prescreen 摘要 `1e2d1f2819de199aaafa1d08a314b6e546f000f2f1cc536950272e6f2e200fc64`；实际 K62 v24 官方附件 ZIP `fb29a18b319b332b70c0d594576395fb922a02e07caa524ed36eed4cbe7058a9` 中两原件摘要分别为 `a4467503072efc41ca8dc0bdd3e727fd8aa2fb2b33d3f31bbe253d14d29052dc`、`1a1c2d627294b82f93f12e278fb253b4363500b2cd53d63cfc3b343d5b5f1080`，与该 ZIP 自带 SHA256SUMS.json 一致。
   - 影响：旧声明不能按原字节复核；不能将两个不同摘要视为同一已核对象。本审独立使用上述真实原件检查60条 exact ID，命中仍为0；这不证明 family non-overlap。
   - 建议改法：1b追加 gate-provenance correction，绑定附件、成员与实际摘要，或补已持有且匹配旧摘要的原件并解释差别；不覆盖历史、不重抓候选。详情 `gate-provenance-review.json` 的6个逐批差异。

2. `pytest-10896/manifest.json:related_refs` 等5处批次标签与已交索引身份不一致。
   - 现象 / 触发条件：#10896→#11895 应为 B7（原 B8）；#10991→#11610 应为 B8（原 B9）；#11140→#12818 应为 B5（原 B4）；#10701→#10687 应为 B11（原 B10）；#10865→#11447 应为 B8（原 B9）。
   - 影响：按批次取家族原件会取错；引用字符串不是可靠原件定位。
   - 建议改法：1b追加规范 target ID / 实际 batch / index pointer 更正，不重写历史字符串。逐项见 `family-review-ledger.json:batch_label_corrections`。

### 🔵 建议（0 项）

### 说明文件一致性

- 已验输入：索引 ZIP `ec93e4c6a4e4e33b2e9e34d2113213a0e8ebf3ce546524cd4fc144253581038a`，commit `0bafa464239358db303c5ce0f2001a012526fbc7`；B9/B10/B11 原件摘要逐项见 `input-packages.json`。
- 三批624个成员摘要、索引9个成员摘要通过。60条公开题面与原始 GraphQL body 字节一致；direct ClosedEvent 查询→同仓 merged PR→merge first-parent/tree→codeload archive SHA/PAX commit→历史 MIT LICENSE / pyproject / tox 声明与索引一致。逐题检查及依据 SHA 见 `review-manifest.json`。MIT核证限固定仓库软件/相关文档的原许可通知，保留其版权/许可条款；不是依赖或所有题面作者内容的统一授权。
- tree 结论限原始 GraphQL OID 与归档 commit 绑定；未重算整棵 Git tree。未打开仓库测试文件正文；题面中已有的公开示例仅作为题面证据。未打开题面链接、PR body/diff/fix、隐藏评测材料；无测试、部署、AA、107、GPU或新采集。
- 66条 related refs（65唯一原字符串）逐项核证：56条仅主题相近且固定身份不同，3条明确指向旧PR，1条讨论，1条报告同类输出问题但缓存 closer=null，4条类型/因果尚不完整，1条具有公开报告回归链。没有已核 backport、没有新增独立root clearance；不把不同PR或无引用视为独立家族。
- #10743 的关闭 PR#10758 被 #11028 题面称为回归来源；#11028 的关闭 PR#11041 又被 #11239 题面报告 bisect 命中。身份绑定核实，因果仅为报告者声明；三个来源保守保留 family-review hold，未运行复现。#11104 对 PR#10988（关闭 #10987）的联系也仅为题面“perhaps”怀疑。
- #10870/#10871 的相同 direct closure PR#10925、merge/base/tree 已从 B11 原始响应确认；#10871 排除保留，不新增题。其未单独打包的归档不声称独立校验。#10815 的原排除保留。另补入 #11137→#7777、#11013→#11006、#11354→#11346、#11356→#11343、#10903→discussion10895、#10710→pytest-reportlog#19、#10865→#9288 等已在原题面的来源/关联，不抓目标正文。
- 14条题面含具体实现/POC建议、8条文档范围、5条开发基础设施范围，类别可重叠；逐题有证据和待确认用途，不自动删除、清洗或改为 train。#11306 的最小复现仅链接外仓，#10896 尚未给出 reducer；均单列未决项。
- K42既有结论仅核源锁/策略元数据，任务级 non-overlap 未验证、actor 不得读 oracle/reference/audit，训练 release 未签；本审未推翻。K62 dev/sealed/旧暴露排除与 pluggy#140↔pytest#2639 hold 保留。每题 source_role UNKNOWN、split UNASSIGNED、actor_visible=false、trusted_acceptance=false、training_release BLOCKED。
- 计数仍为364 metadata /344 material /320 pinned /85 SOURCE_READY /0 deployable /0 training-approved。新增60条来源链 VERIFIED、0条新增独立root、0 SOURCE_READY增量。来源核证不是400道可用题完成，也不是K42最终训练准入。

### 复核清单

- [x] `python -X utf8 finalize_review.py`（调用离线字节核证脚本）：退出0，60条来源检查通过；未执行候选代码或测试。
- [x] `family-review-ledger.json` 覆盖66条引用、11条补充关联及5处标签更正；未知项逐题/逐target说明缺件。
- [ ] 1b追加门禁原件绑定更正与5处批次定位更正，保留历史字节。
- [ ] 1b仅从已有供件补每题缺失的用途、family/root/backport与dev/sealed/旧暴露归属/排除记录；无原件则保持UNKNOWN，不代签clearance。
- [ ] 真正需要现场验证的环境/功能部分继续依赖K69恢复及原执行链；本次不启动该链、不重试被拒模型、不恢复B12采集。

交接唯一负责人：1b（K68当前owner）。追加 review ledger 与证据摘要，不重新采集、不改写本包及旧索引、不自行推翻上游门。没有产品代码修改，不需要PR。

复核重放：将 `input-packages.json` 所列五个原始ZIP按原名放在包根目录的 `inputs/`，执行 `python -X utf8 finalize_review.py`。这是文件/元数据核证脚本，不是候选测试。原始源码归档不重复装入本包，仍由原附件及SHA定位。
