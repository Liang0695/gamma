When using a custom test directory, other than `tests/` the `pytest_sessionstart` hook (or the maybe also the entire `conftest.py`) is not run. The issue appeared at `pytest` version 7.3.1 under Windows 10.

I created a minimum working example that shows the problem at https://github.com/padix-key/pytest-issue. When the tests folder `some_path` is renamed to `tests` `pytest_sessionstart`()` is sucessfully run, indicated by the raised Exception. Otherwise it is not run.
