Python 3.8 introduced the [typing.TypedDict](https://docs.python.org/3/library/typing.html#typing.TypedDict) type to properly annotate dicts with multiple types. It appears that this type is not compatible with the type annotations for `monkeypatch.setitem`.

The following code runs fine with pytest:
```python
from typing import TypedDict

from _pytest.monkeypatch import MonkeyPatch

Foo = TypedDict('Foo', {'x': int, 'y': float})

a: Foo = {'x': 1, 'y': 3.14}
b = {'x': 1, 'y': 3.14}

def test(monkeypatch: MonkeyPatch) -> None:
    monkeypatch.setitem(a, 'x', 2)
    monkeypatch.setitem(b, 'x', 2)
```
However, it fails with mypy:
```console
$ mypy test.py
test.py:11: error: Argument 1 to "setitem" of "MonkeyPatch" has incompatible type "Foo"; expected "MutableMapping[str, int]"  [arg-type]
Found 1 error in 1 file (checked 1 source file)
```

### Versions

* Python 3.10.10
* pytest 7.2.1
* macOS 13.3.1 (a)