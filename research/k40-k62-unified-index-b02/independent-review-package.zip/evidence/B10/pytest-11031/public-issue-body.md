## Add additional flag CLI flag to the Ini Options: `--config-file`

### What's the current situation?

The PyTest config currently has one config flag that can be used for loading config from a file: `-c`. As outlined [here][pytest_cli_flag_-c] and [here][pytest_config_from_file].

This means that if I wanted to run my `pytest` script from a `pyproject.toml` file, I'd need to run it like this:

```sh
pytest -c pyproject.toml
```

With the `pyproject.toml` file containing the following config:

```toml
[tool.pytest.ini_options]
addopts = "--verbose --cov=src --cov-report=term --cov-report=html:cov-report/html --cov-report=xml:cov-report/xml/cov-report.xml"
testpaths = [
    "src",
]
```

### What's the problem this feature will solve?

The current solution works. However, for someone new to the team, who see this flag `-c`, they'd need to go digging through the documentation to try and find out what it means. Which may take some time.

### Describe the solution you'd like

To streamline this process, I'd like to add an additional flag to the existing `-c` flag. This new flag should be a double-hyphen flag, and be either `--config` or `--config-file`.

That way, it is clear and unmistakable what this flag would be doing.

Therefore, in addition to running the command like this:

```sh
pytest -c pyproject.toml
```

This command should also work just the same if the command looked like this:

```sh
pytest --config-file pyproject.toml
```

### Additional context

By way of context, other Python packages that also supply config in the `pyproject.toml` file also have the longer version of the flag in their CLI config.

For example:

- MyPy uses the command: `--config-file CONFIG_FILE`. See [here][mypy_cli_flag_--config-file].
- Black uses the command: `--config FILE`. See [here][black_cli_flag_--config].

It would be beneficial if PyTest could also implement a flag similar to Packages like this.

[pytest_cli_flag_-c]: https://docs.pytest.org/en/7.3.x/reference/reference.html#ini-options-ref:~:text=to%20%2D%2Dstrict%2Dmarkers-,%2Dc,-file%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20Load%20configuration
[pytest_config_from_file]: https://docs.pytest.org/en/stable/reference/customize.html
[mypy_cli_flag_--config-file]: https://mypy.readthedocs.io/en/stable/command_line.html#cmdoption-mypy-config-file
[black_cli_flag_--config]: https://black.readthedocs.io/en/stable/usage_and_configuration/the_basics.html#:~:text=version%20and%20exit.-,%2D%2Dconfig,-FILE%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20Read%20configuration
