Hi pytest developers,

in the API documentation for [config.cache](https://docs.pytest.org/en/latest/reference/reference.html#config-cache) you wrote that the access should be done with the `pytestconfig` fixture. But in the example in [The new config.cache object](https://docs.pytest.org/en/latest/how-to/cache.html#the-new-config-cache-object) you use the `request` fixture.

Please consider updating the example to be consistent with the API documentation.

Thank you,
Carsten