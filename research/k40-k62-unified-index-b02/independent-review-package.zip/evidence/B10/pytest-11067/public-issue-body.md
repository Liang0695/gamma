content of `conftest.py`:

```python
@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()

    if report.when == 'call':
        xfail = hasattr(report, 'wasxfail')        
        if not report.failed and not report.skipped and not xfail:
            print("Passed")
        elif report.failed and not report.skipped:
            print("Failed")
        elif not report.failed and not report.skipped and xfail:
            print("XPassed")
        elif not report.failed and report.skipped:
            print("XFailed")
            if xfail:
                print("Reason: ", report.wasxfail)
```

content of `xfailed_test.py`:

```
import pytest

@pytest.mark.xfail(reason="test_1")
def test_1():
    assert False

def test_2():
    pytest.xfail(reason="test_2")
```

The output of the test is:

```
XFailed
Reason: test_1
XFailed
Reason:  reason: test_2
```
The first test xfailed because of a marker, and the second test xfailed due to an explicit call to `pytest.fail` function.

The outputs are not coherent

The output for **test_2** should be `Reason: test_2` instead of `Reason:  reason: test_2`

Tested with version 7.3.1