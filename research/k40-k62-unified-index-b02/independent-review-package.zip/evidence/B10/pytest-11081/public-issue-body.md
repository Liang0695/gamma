Currently the two recursive collectors `Session` and `Package` perform the `norecursedir` check directly in the collector:

https://github.com/pytest-dev/pytest/blob/85c5bd26b6d94dca423c2c0c54717750eac81cae/src/_pytest/main.py#L566-L568

https://github.com/pytest-dev/pytest/blob/85c5bd26b6d94dca423c2c0c54717750eac81cae/src/_pytest/python.py#L709-L711

I think it would be strictly better to move this check to `main`'s [`pytest_ignore_collect` hookimpl](https://github.com/pytest-dev/pytest/blob/85c5bd26b6d94dca423c2c0c54717750eac81cae/src/_pytest/main.py#L377):

- Less duplication
- Better decoupling -- only main knows about the option it defines
- More control for plugins