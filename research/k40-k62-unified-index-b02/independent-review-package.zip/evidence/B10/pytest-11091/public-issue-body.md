The docs and cli help are a bit confusing around the `--junitxml`/`--junit-xml` cli option (and probably some comparable options).


`pytest --help` only mentions `--junit-xml=path` (e.g. also see https://docs.pytest.org/en/7.1.x/reference/reference.html#command-line-flags):
```text
  --junit-xml=path      Create junit-xml style report file at given path
```

However, most examples in the docs (and mosts tests) use `--junitxml`, e.g. https://github.com/pytest-dev/pytest/blob/0ded3297a9749aabad7d3c2447dce98321741dda/doc/en/how-to/output.rst#creating-junitxml-format-files :

```rst
To create result files which can be read by Jenkins_ or other Continuous
integration servers, use this invocation:

.. code-block:: bash

    pytest --junitxml=path

to create an XML file at ``path``.
```

This was quite confusing to me as it seemed there was a typo somewhere and I lost time just to figure out that they are aliases actually:

https://github.com/pytest-dev/pytest/blob/0ded3297a9749aabad7d3c2447dce98321741dda/src/_pytest/junitxml.py#L384-L386



Wouldn't it be better to stick to one of the two everywhere or at least more explicitly mention that they are aliases?