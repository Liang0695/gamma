*Note: this issue is extracted verbatim from https://github.com/pytest-dev/pytest/issues/7777#issuecomment-1575652688 so I can refer to it separately*

`Package` is currently a subclass of a `Module`, with `package.path` being the `__init__.py` file.

While technically in terms of the Python data model this [is correct](https://docs.python.org/3/glossary.html#term-package), I'm pretty convinced this was the wrong decision in pytest:

`Package` is a `Module` with path `__init__.py`, but it doesn't actually act as a `Module` behaviorally, it overrides everything that `Module` does and doesn't call `super()` on anything.

`Module` is a `nodes.File`, which makes `Package` a `nodes.File`, but it doesn't act as a file.

The previous points can be rephrased as: `Package` breaks Liskov substitution -- any code dealing with `File` or `Module` generically probably doesn't want `Package`.

`Package` is a `Module` with path `__init__.py`, but it actually collects a "real" (non-`Package`) `Module` for the `__init__.py` file (if permitted by `python_files` glob). This is very confusing.

`Package` and `__init__.py` necessitates several special-casings because of these points:

- https://github.com/pytest-dev/pytest/blob/24534cdd29d74e302e86db1a719c99e024d7903e/src/_pytest/cacheprovider.py#L275-L278
- https://github.com/pytest-dev/pytest/blob/24534cdd29d74e302e86db1a719c99e024d7903e/src/_pytest/main.py#L805-L818
- https://github.com/pytest-dev/pytest/blob/24534cdd29d74e302e86db1a719c99e024d7903e/src/_pytest/fixtures.py#L123
- https://github.com/pytest-dev/pytest/blob/24534cdd29d74e302e86db1a719c99e024d7903e/src/_pytest/python.py#L229-L231
- https://github.com/pytest-dev/pytest/blob/24534cdd29d74e302e86db1a719c99e024d7903e/src/_pytest/python.py#L750-L761

### Proposed solution

As part of the breaking `Package` changes discussed previously in this issue, also make these changes

- `Package` no longer inherits from `Module` (or `File` by extension), just from `FSCollector`.
- `Package.path` is the package directory, not the `__init__.py` file.
- Collecting `pkg/__init__.py` collects the `__init__.py` file as a module (file), doesn't collect the entire package.

This also matches the new `Directory` node, which is the non-`Package` directory collector. `Directory` will inherit just from `FSCollector` and its `path` will be the directory. It will be much better if they are as similar to each other as possible.

### Complication

Currently `Package`  has a `setup()` method which imports the `__init__.py`' and runs its `setup_module` function and registers `teardown_module` finalizer (in effectively the package scope). If we want to stop having `Package` as a `Module` it becomes a bit less natural to implement.

This functionality has some issues:
- It is undocumented.
- It doesn't match `unittest` which doesn't have package functionality
- The names `setup_module` and `teardown_module` conflict with the "real" `__init__.py` `Module` setup/teardown; i.e., these methods are executed twice, if the `__init__.py` is included in the glob. It would have been better to call them `setup_package`/`teardown_package` (this is how nose [calls them](https://nose.readthedocs.io/en/latest/writing_tests.html#test-packages)).

It is tempting to just remove it, but it will probably cause some breakage (particularly the `__init__.py` importing part), so for now I plan to keep it in an ad-hoc manner.

### POC

I have an initial implementation of this change here, with all tests passing:
https://github.com/bluetech/pytest/commits/pkg-mod