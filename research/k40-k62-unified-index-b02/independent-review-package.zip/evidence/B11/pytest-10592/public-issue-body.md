Hi,

When using `py.test-3 --cache-show --help` or `python3 -m pytest --cache-show --help`, I can reliably trigger an internal error.

The full stack trace is:

```
========================================== test session starts ==========================================
platform linux -- Python 3.10.9, pytest-7.1.2, pluggy-1.0.0+repack
INTERNALERROR> Traceback (most recent call last):
INTERNALERROR>   File "/usr/lib/python3/dist-packages/_pytest/main.py", line 266, in wrap_session
INTERNALERROR>     config.hook.pytest_sessionstart(session=session)
INTERNALERROR>   File "/usr/lib/python3/dist-packages/pluggy/_hooks.py", line 265, in __call__
INTERNALERROR>     return self._hookexec(self.name, self.get_hookimpls(), kwargs, firstresult)
INTERNALERROR>   File "/usr/lib/python3/dist-packages/pluggy/_manager.py", line 80, in _hookexec
INTERNALERROR>     return self._inner_hookexec(hook_name, methods, kwargs, firstresult)
INTERNALERROR>   File "/usr/lib/python3/dist-packages/pluggy/_callers.py", line 60, in _multicall
INTERNALERROR>     return outcome.get_result()
INTERNALERROR>   File "/usr/lib/python3/dist-packages/pluggy/_result.py", line 60, in get_result
INTERNALERROR>     raise ex[1].with_traceback(ex[2])
INTERNALERROR>   File "/usr/lib/python3/dist-packages/pluggy/_callers.py", line 39, in _multicall
INTERNALERROR>     res = hook_impl.function(*args)
INTERNALERROR>   File "/usr/lib/python3/dist-packages/_pytest/terminal.py", line 710, in pytest_sessionstart
INTERNALERROR>     lines = self.config.hook.pytest_report_header(
INTERNALERROR>   File "/usr/lib/python3/dist-packages/_pytest/config/compat.py", line 67, in fixed_hook
INTERNALERROR>     return hook(**kw)
INTERNALERROR>   File "/usr/lib/python3/dist-packages/pluggy/_hooks.py", line 265, in __call__
INTERNALERROR>     return self._hookexec(self.name, self.get_hookimpls(), kwargs, firstresult)
INTERNALERROR>   File "/usr/lib/python3/dist-packages/pluggy/_manager.py", line 80, in _hookexec
INTERNALERROR>     return self._inner_hookexec(hook_name, methods, kwargs, firstresult)
INTERNALERROR>   File "/usr/lib/python3/dist-packages/pluggy/_callers.py", line 60, in _multicall
INTERNALERROR>     return outcome.get_result()
INTERNALERROR>   File "/usr/lib/python3/dist-packages/pluggy/_result.py", line 60, in get_result
INTERNALERROR>     raise ex[1].with_traceback(ex[2])
INTERNALERROR>   File "/usr/lib/python3/dist-packages/pluggy/_callers.py", line 39, in _multicall
INTERNALERROR>     res = hook_impl.function(*args)
INTERNALERROR>   File "/usr/lib/python3/dist-packages/_pytest/terminal.py", line 732, in pytest_report_header
INTERNALERROR>     if config.invocation_params.dir == config.rootpath and config.args == testpaths:
INTERNALERROR> AttributeError: 'Config' object has no attribute 'args'
```


I am using pytest 7.1.2 from Debian (deb version is 7.1.2-4) on python3 (3.10.9)