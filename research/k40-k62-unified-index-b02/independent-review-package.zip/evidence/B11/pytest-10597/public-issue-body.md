If a test fixture is called `teardown`, the tests fail with a message:

_Fixture "teardown" called directly. Fixtures are not meant to be called directly, but are created automatically when test functions request them as parameters_

even if the test code doesn't explicitly call this fixture.

### Test code
```python
class TestHelloWorld:

    @pytest.fixture(scope="function", autouse=True)
    def teardown(self):
        yield
        print("teardown")

    def test_helloworld(self):
        assert True
```

### Steps to reproduce the issue

* Create a test file like the one above
* Run `python -m pytest`

**Expected behavior**:
The test suite passes without errors.

**Actual behavior**:
The result is "*1 passed, 1 error*", with the following message:
> Fixture "teardown" called directly. Fixtures are not meant to be called directly,
> but are created automatically when test functions request them as parameters.
> 
> See https://docs.pytest.org/en/stable/explanation/fixtures.html for more information about fixtures, and
> https://docs.pytest.org/en/stable/deprecations.html#calling-fixtures-directly about how to update your code.

### Additional information
* Renaming the fixture from `teardown` to something else (like `teardown2`) results in the expected behavior.
* Removing the `autouse` parameter, or changing the scope to `class`, does not result in the expected behavior.
* The failure is reproduced starting from pytest 7.0.0rc1. It's not reproducible with 6.2.5.



Pip list:
```$ pip list
Package    Version
---------- -------
attrs      22.2.0
iniconfig  1.1.1
packaging  22.0
pip        22.3.1
pluggy     1.0.0
pytest     7.2.0
setuptools 65.5.0
```
Environment:
* pytest 7.2.0
* OS: Ubuntu 22.04.1 LTS
* Python 3.11

Sample reproduction project: https://github.com/caarmen/pytest-teardown-issue
