PyTest can intermittently fail when finalizing the run, if flag `--junitxml=<path_to_file.xml>` is set. This causes to errors similar to:

```cmd
[...]
  File "D:\workspace\o3de\python\runtime\python-3.10.5-rev1-windows\python\lib\site-packages\_pytest\junitxml.py", line 650, in pytest_sessionfinish
    os.makedirs(dirname)
  File "D:\workspace\o3de\python\runtime\python-3.10.5-rev1-windows\python\lib\os.py", line 225, in makedirs
    mkdir(name, mode)
FileExistsError: [WinError 183] Cannot create a file when that file already exists: 'D:\\workspace\\o3de\\build\\windows\\Testing\\Pytest'
```

This appears to primarily happen when running multiple invocations of pytest in parallel interpreters, where two instances may try to create the same folder at the same time. Though this has also reproduced in a self-test of a plugin, which invoked pytest within the context of another pytest run.

This has reproduced on pytest `6.2.5` and `7.2.0` on both Windows and Linux.

Output of `pip list` is attached [piplist.txt](https://github.com/pytest-dev/pytest/files/10282188/piplist.txt)

I am currently testing a fix to this by monkeypatching https://github.com/pytest-dev/pytest/blob/7.2.x/src/_pytest/junitxml.py#L649 to use `os.makedirs(dirname, exist_ok=True)` ...but I plan to collect more data on whether other race conditions still exist before proposing a PR.