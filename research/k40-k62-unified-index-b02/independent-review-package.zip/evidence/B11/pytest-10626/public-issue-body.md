## minimal example

```python-traceback
$ pytest --fixtures --help
=============== test session starts ===============
platform darwin -- Python 3.11.0, pytest-7.2.0, pluggy-1.0.0
INTERNALERROR> Traceback (most recent call last):
INTERNALERROR>   File "/private/tmp/foo/.venv/lib/python3.11/site-packages/_pytest/main.py", line 268, in wrap_session
INTERNALERROR>     config.hook.pytest_sessionstart(session=session)
INTERNALERROR>   File "/private/tmp/foo/.venv/lib/python3.11/site-packages/pluggy/_hooks.py", line 265, in __call__
INTERNALERROR>     return self._hookexec(self.name, self.get_hookimpls(), kwargs, firstresult)
INTERNALERROR>            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
INTERNALERROR>   File "/private/tmp/foo/.venv/lib/python3.11/site-packages/pluggy/_manager.py", line 80, in _hookexec
INTERNALERROR>     return self._inner_hookexec(hook_name, methods, kwargs, firstresult)
INTERNALERROR>            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
INTERNALERROR>   File "/private/tmp/foo/.venv/lib/python3.11/site-packages/pluggy/_callers.py", line 60, in _multicall
INTERNALERROR>     return outcome.get_result()
INTERNALERROR>            ^^^^^^^^^^^^^^^^^^^^
INTERNALERROR>   File "/private/tmp/foo/.venv/lib/python3.11/site-packages/pluggy/_result.py", line 60, in get_result
INTERNALERROR>     raise ex[1].with_traceback(ex[2])
INTERNALERROR>   File "/private/tmp/foo/.venv/lib/python3.11/site-packages/pluggy/_callers.py", line 39, in _multicall
INTERNALERROR>     res = hook_impl.function(*args)
INTERNALERROR>           ^^^^^^^^^^^^^^^^^^^^^^^^^
INTERNALERROR>   File "/private/tmp/foo/.venv/lib/python3.11/site-packages/_pytest/terminal.py", line 720, in pytest_sessionstart
INTERNALERROR>     lines = self.config.hook.pytest_report_header(
INTERNALERROR>             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
INTERNALERROR>   File "/private/tmp/foo/.venv/lib/python3.11/site-packages/_pytest/config/compat.py", line 67, in fixed_hook
INTERNALERROR>     return hook(**kw)
INTERNALERROR>            ^^^^^^^^^^
INTERNALERROR>   File "/private/tmp/foo/.venv/lib/python3.11/site-packages/pluggy/_hooks.py", line 265, in __call__
INTERNALERROR>     return self._hookexec(self.name, self.get_hookimpls(), kwargs, firstresult)
INTERNALERROR>            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
INTERNALERROR>   File "/private/tmp/foo/.venv/lib/python3.11/site-packages/pluggy/_manager.py", line 80, in _hookexec
INTERNALERROR>     return self._inner_hookexec(hook_name, methods, kwargs, firstresult)
INTERNALERROR>            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
INTERNALERROR>   File "/private/tmp/foo/.venv/lib/python3.11/site-packages/pluggy/_callers.py", line 60, in _multicall
INTERNALERROR>     return outcome.get_result()
INTERNALERROR>            ^^^^^^^^^^^^^^^^^^^^
INTERNALERROR>   File "/private/tmp/foo/.venv/lib/python3.11/site-packages/pluggy/_result.py", line 60, in get_result
INTERNALERROR>     raise ex[1].with_traceback(ex[2])
INTERNALERROR>   File "/private/tmp/foo/.venv/lib/python3.11/site-packages/pluggy/_callers.py", line 39, in _multicall
INTERNALERROR>     res = hook_impl.function(*args)
INTERNALERROR>           ^^^^^^^^^^^^^^^^^^^^^^^^^
INTERNALERROR>   File "/private/tmp/foo/.venv/lib/python3.11/site-packages/_pytest/terminal.py", line 741, in pytest_report_header
INTERNALERROR>     if config.args_source == Config.ArgsSource.TESTPATHS:
INTERNALERROR>        ^^^^^^^^^^^^^^^^^^
INTERNALERROR> AttributeError: 'Config' object has no attribute 'args_source'
```

## pip list

```
Package    Version
---------- -------
attrs      22.2.0
iniconfig  1.1.1
packaging  22.0
pip        22.3.1
pluggy     1.0.0
pytest     7.2.0
setuptools 65.6.3
wheel      0.38.4
```

## pytest and operating system versions

```
$ python -V
Python 3.11.0

$ pytest -V
pytest 7.2.0

$ sw_vers
ProductName:		macOS
ProductVersion:		13.0.1
BuildVersion:		22A400
```