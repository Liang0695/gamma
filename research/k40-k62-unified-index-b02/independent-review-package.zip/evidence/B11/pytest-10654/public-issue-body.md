#### What's the problem this feature will solve?

Sometimes it's convenient to parameterize both raising and non-raising case, e.g.

```python
@pytest.mark.parameterize(['value', 'exception_expected'], [
    ('good', None),
    ('bogus', ValueError),
])
def test_foobar(value, exception_expected):
    with maybe_raises(exception_expected) as exc_info:
        foobar(
            value,
            constant_value="no need to repeat twice",
        )
    if exc_info:
        assert exc_info.value == 'message'
```

With pytest as it stands, I'd have to do something more akward like:
```python
if exception_expected:
    with pytest.raises(exception_expected) as exc_info:
        foobar(...)
    assert exc_info.value == 'message'
```
or if I prefer not to repeat the call:
```python
with pytest.raises(exception_expected) if exception_expected else nullcontext():
    foobar(...)
```

#### Describe the solution you'd like

Here's the snippet from my project's test helper module:

```python
E = TypeVar('E', bound=BaseException)


def maybe_raises(
    expected_exception: Union[Type[E], Tuple[Type[E], ...], None],
    *,
    match: Optional[Union[str, Pattern[str]]] = None,
) -> ContextManager[Optional[pytest.ExceptionInfo]]:
    if expected_exception is not None:
        return pytest.raises(expected_exception, match=match)
    else:
        return contextlib.nullcontext()
```

#### Alternative Solutions

1. The code above is from my project code, so it's possible to complement pytest rather than add to it. However, since I found this to be a useful pattern, I'd like to propose adding it to pytest.

2. We can make `pytest.raises` accept an optional exception and return a `ContextManager[Optional[pytest.ExceptionInfo]]`. As-is it'd be a breaking change, but we could perhaps do this as an `@override`.
