Hi, I'm trying to raise an error when I get a string like

"Only 10000 rows were downloaded{extra_stuff_not_in_actual_string}client_row_transfer_limit{more_stuff_in_string}"

and I just want to raise an error for `UserWarning`s with messages containing the substring `"client_row_transfer_limit"`.

This is easy to do with a regex matching the start of the string with the `filterwarnings` ini option:

```
#pytest.ini
[pytest]
filterwarnings =
	error:.*client_row_transfer_limit:UserWarning
```

I'm using [pants pytest](https://www.pantsbuild.org/docs/reference-pytest) to run my test, and pants doesn't support the `filterwarnings` option, but it does support passing command-line args to pytest, so I passed `"-W error:.*client_row_transfer_limit.*:UserWarning"`, which seemed to match the warning filter string syntax [here](https://docs.python.org/3/library/warnings.html#describing-warning-filters) that pytest links to. I was very confused to see that pytest wasn't raising any errors. After some digging, I found that the `message` and `module` components of the warnings filter are [interpreted differently](https://docs.python.org/3/library/warnings.html#the-warnings-filter) for the python argument `-W` (outside of the pytest context), and that 

>  message is a literal string that the start of the warning message must contain (case-insensitively), ignoring any whitespace at the start or end of message

I tried `"-W error:Only:UserWarning"` and that finally matched the warning. I have two complaints:

- pytest documentation should warn that when using `-W` instead of `filterwarnings`, the `message` and `module` params are interpreted differently
- Is there any reason that pytest `-W` has to follow the convention of the [generic python command-line option](https://docs.python.org/3/using/cmdline.html#cmdoption-W) `-W`? Message pattern matching for `-W` is not as powerful. In this example, I only care about the `client_row_transfer_limit` part which appears at the beginning of  my message.

- [x] a detailed description of the bug or problem you are having
- [ ] output of `pip list` from the virtual environment you are using
- [x] pytest and operating system versions
- [ ] minimal example if possible
