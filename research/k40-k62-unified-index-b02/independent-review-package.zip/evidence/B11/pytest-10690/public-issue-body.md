

I'm new to pytest, but should ["CI" and "BUILD_NUMBER"](https://github.com/pytest-dev/pytest/blob/main/src/_pytest/assertion/util.py#L519-L522) be added to the ["Environment Variables" section ](https://docs.pytest.org/en/7.2.x/reference/reference.html#environment-variables)of the reference?

_Originally posted by @TurekBot in https://github.com/pytest-dev/pytest/issues/9933#issuecomment-1397920487_
            