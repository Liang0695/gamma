When trying to pop a specific warning from a WarningsRecorder instance, the wrong warning is returned. I believe the issue is that pop uses issubclass https://github.com/pytest-dev/pytest/blob/3c1534944cbd34e8a41bc9e76818018fadefc9a1/src/_pytest/recwarn.py#L210

I believe the correct comparison should be:
```python
if w.category is cls:
```

Here is a minimum working example that triggers the buggy behavior:
```python
import pytest
import warnings

class RWarning(Warning):
    pass
    
class SWarning(RWarning):
    pass

def raise_warnings():
    warnings.warn("Warning 1", SWarning)
    warnings.warn("Warning 2", RWarning)
    
def test_pop():
    with pytest.warns((RWarning, SWarning)) as record:
        raise_warnings()
        
    assert len(record) == 2
    _warn = record.pop(RWarning)
    assert _warn.category is RWarning  # This fails because _warn.category is SWarning
```
The test output is
```
========================================================================================= FAILURES ==========================================================================================
_________________________________________________________________________________________ test_pop __________________________________________________________________________________________

    def test_pop():
        with pytest.warns((RWarning, SWarning)) as record:
            raise_warnings()

        assert len(record) == 2
        _warn = record.pop(RWarning)
>       assert _warn.category is RWarning
E       AssertionError: assert <class 'pytest_bug.SWarning'> is RWarning
E        +  where <class 'pytest_bug.SWarning'> = <warnings.WarningMessage object at 0x7fea08a72010>.category

pytest_bug.py:24: AssertionError
```

pytest 7.2.1 on archlinux.
virtual environment is a clean conda environment with only python and pytest (and their dependencies installed from conda-forge).

If this is indeed a bug, I'm happy to open a PR with my proposed solution.
