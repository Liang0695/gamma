#### What's the problem this feature will solve?
<!-- What are you trying to do, that you are unable to achieve with pytest as it currently stands? -->
When parsing pytest report (in my case --reportlog file) TestReport objects only contain duration information. I'm missing start and stop timestamps to be able to correlate test results with external events.
#### Describe the solution you'd like
<!-- A clear and concise description of what you want to happen. -->
TestReport objects should have .start and .stop attributes set, which can easily be copied from CallInfo objects in TestReport.from_item_and_call
<!-- Provide examples of real-world use cases that this would enable and how it solves the problem described above. -->

#### Alternative Solutions
<!-- Have you tried to workaround the problem using a pytest plugin or other tools? Or a different approach to solving this issue? Please elaborate here. -->
I considered adding it to pytest-reportlog here - https://github.com/pytest-dev/pytest-reportlog/pull/22, but we agreed that core pytest is a better place for such change.
#### Additional context
<!-- Add any other context, links, etc. about the feature here. -->
Initial feature request in pytest-reportlog - https://github.com/pytest-dev/pytest-reportlog/issues/19