Our unit test suite is always failing when building for emscripten-wasm32, because getuid in emscripten always returns 0.  This causes the following exception to always trip:

https://github.com/pytest-dev/pytest/blob/9ccae9a8e3c7bb532eb7dc225f4c68f7dd5a8534/src/_pytest/tmpdir.py#L179-L189

The trivial fix is just to add `and sys.platform != "emscripten"` to the `if` check.  Adding this makes our test suite pass.

I would have made a PR but I don't want to add my name to AUTHORS.

Encountered with Python 3.11.2+, pytest 7.2.1, and node.js v14.18.2.