### Description

If one follows the [Good Integration Practices](https://docs.pytest.org/en/7.1.x/explanation/goodpractices.html) tutorial, then the command
```shell
pip install -e .
```
gives the following error :
```shell
  × Preparing editable metadata (pyproject.toml) did not run successfully.
  │ exit code: 1
  ╰─> [34 lines of output]
    ...

     ValueError: Field `project.version` can only be resolved dynamically if `version` is in field `project.dynamic
```
This is due to the fact that the version is not set in the sample `pyproject.toml`.

### Output of `pip list`

```
Package           Version Editable project location
----------------- ------- -------------------------------------------------
attrs             22.2.0
black             23.1.0
click             8.1.3
colorama          0.4.6
contourpy         1.0.7
cycler            0.11.0
fonttools         4.38.0
iniconfig         2.0.0
kiwisolver        1.4.4
matplotlib        3.7.0
mypy              1.0.1
mypy-extensions   1.0.0
numpy             1.24.2
packaging         23.0
pathspec          0.11.0
Pillow            9.4.0
pip               23.0.1
platformdirs      3.0.0
pluggy            1.0.0
pyparsing         3.0.9
pytest            7.2.1
python-dateutil   2.8.2
setuptools        65.5.0
six               1.16.0
typing_extensions 4.5.0
```

### Pytest and OS version

- pytest: 7.2.1
- OS: Windows 10 Entreprise version 22H2

### Minimal example

Follow the [Good Integration Practices](https://docs.pytest.org/en/7.1.x/explanation/goodpractices.html).

### Fix

Change the `pyproject.toml` in the example to:

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "PACKAGENAME"
version = "0.1.0"
```