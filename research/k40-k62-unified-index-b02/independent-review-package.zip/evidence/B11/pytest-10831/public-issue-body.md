Given test changed as
```diff
 import pytest

 def test_foo():
-    pytest.fail('my message')
+    pytest.fail('my message', pytrace=False) 
```
and invoked as
```
pytest --tb=line test_foo.py
```
results in output
```diff
 == FAILURES ==
-.../test_foo.py:4: Failed: my message
+None
```

**Expected:** Output remains the same
```
== FAILURES ==
.../test_foo.py:4: Failed: my message
```