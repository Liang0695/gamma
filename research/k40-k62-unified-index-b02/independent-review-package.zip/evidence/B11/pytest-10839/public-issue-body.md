#### What's the problem this feature will solve?
Pytest cannot evaluate fixture that are async functions or async generators. Users of async pytest plugins may unintentionally annotate those functions with `@pytest.fixture` rather than the async plugin's fixture function.

The fixture result ends up to be an unawaited async generator or coroutine, which is not what the user expected. Most of the time, the corresponding tests will fail. However, when the user defines an autouse fixture to perform setup or teardown, the fixture can silently fail.

##### Fixture results in async generator
```
import pytest

@pytest.fixture
async def async_fixture():
    yield 42

def test_this(async_fixture):
    assert async_fixture == 42  # fails
```

##### Fixture results in coroutine
```
import pytest

@pytest.fixture
async def async_fixture():
    return 42

def test_this(async_fixture):
    assert async_fixture == 42  # fails
```

##### Fixture silently does nothing
```
import pytest

@pytest.fixture(autouse=True)
async def async_fixture():
    yield 42
   # perform teardown

def test_this():
    assert True  # succeeds but should fail
```

#### Describe the solution you'd like
Pytest emits the following warning when running async test functions without an async plugin (see #2224):
```
PytestUnhandledCoroutineWarning: async def functions are not natively supported and have been skipped.
  You need to install a suitable plugin for your async framework, for example:
    - anyio
    - pytest-asyncio
    - pytest-tornasync
    - pytest-trio
    - pytest-twisted
```

The warning is emitted as part of a *trylast* hook to `pytest_pyfunc_call`. That means async pytest plugins can create hook wrappers to synchronize the test function and prevent the warning from being emitted.

<!-- A clear and concise description of what you want to happen. -->
I suggest to add the same behavior to the use of `@pytest.fixture` on async functions or async generators.

<!-- Provide examples of real-world use cases that this would enable and how it solves the problem described above. -->
Examples
* https://github.com/pytest-dev/pytest-asyncio/issues/518
* https://github.com/pytest-dev/pytest-asyncio/issues/286
* https://github.com/pytest-dev/pytest-asyncio/issues/390
* https://github.com/pytest-dev/pytest-asyncio/issues/386


#### Alternative Solutions
<!-- Have you tried to workaround the problem using a pytest plugin or other tools? Or a different approach to solving this issue? Please elaborate here. -->
#9962 proposes a mechanism to await results of awaitable tests and fixtures. It can potentially address the issue described here.

#### Additional context
<!-- Add any other context, links, etc. about the feature here. -->
From the above list of async plugins, only anyio, pytest-asyncio, and pytest-trio make use of *pytest_fixture_setup*.
