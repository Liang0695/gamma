<!--
Thanks for submitting an issue!

Quick check-list while reporting bugs:
-->

- [x] a detailed description of the bug or problem you are having
- ~[ ] output of `pip list` from the virtual environment you are using~
- [x] pytest and operating system versions
- [x] minimal example if possible

When using `pytest.warns`, incorrect values sent to `warnings.warn` are not reported obscuring bugs:

```python
import pytest
import warnings


def test_example_one():
    with pytest.warns(UserWarning):
        warnings.warn(1)

    # This test passes but should raise a `TypeError` as demonstrated in `example_two`


def test_example_two():
    with pytest.raises(TypeError):
        warnings.warn(1)
```

```
macOS 13.2.1
pytest 7.2.2
python 3.11
```

Related to https://github.com/pytest-dev/pytest/issues/9288