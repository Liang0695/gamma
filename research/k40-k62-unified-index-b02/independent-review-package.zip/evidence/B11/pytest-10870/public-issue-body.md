https://docs.pypi.org/trusted-publishers/

This is currently still in beta, and I don't think pytest should be a beta tester, but opening this issue for discussion ahead of time.

Seems like a good improvement over the API token method we currently use.