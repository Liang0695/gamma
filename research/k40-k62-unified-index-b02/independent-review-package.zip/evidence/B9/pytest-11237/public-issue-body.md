- [x] a detailed description of the bug or problem you are having
If I have doctests in a function decorated with `@cached_property`, they will not be run.
- [x] output of `pip list` from the virtual environment you are using
```
Package           Version Editable project location
----------------- ------- ---------------------------------------------
coverage          6.5.0
exceptiongroup    1.1.2
iniconfig         2.0.0
nodeenv           1.8.0
packaging         23.1
pip               23.2
pluggy            1.2.0
pyright           1.1.318
pytest            7.4.0
setuptools        68.0.0
tomli             2.0.1
typing_extensions 4.7.1
wheel             0.38.4
```
- [x] pytest and operating system versions
pytest 7.4.0
Pop!_OS 22.04 LTS
- [x] minimal example if possible
```python
from functools import cached_property

class Test:
    @cached_property
    def test_me(self):
        """
        A function that returns the string `ok`

        Examples
        --------
        >>> Test().test_me
        'ok'
        """
        return "ok"

    @property
    def test_me_2(self):
        """
        A function that returns the string `ok`

        Examples
        --------
        >>> Test().test_me_2
        'ok'
        """
        return "ok"
```
Run `python -m pytest --doctest-modules`, only one test will be captured and run.