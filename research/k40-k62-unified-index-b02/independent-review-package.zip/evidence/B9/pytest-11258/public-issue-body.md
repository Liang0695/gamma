#### What's the problem this feature will solve?
I think the [Parametrizing conditional raising](https://docs.pytest.org/en/7.4.x/example/parametrize.html#parametrizing-conditional-raising) misses the crucial point:<br>
Actually checking **both**, the expected output for input that does not cause an exception to be raised **and** the exception being raised for input where this is expected:

#### Describe the solution you'd like
Simply using this:

```python
from contextlib import nullcontext as does_not_raise

import pytest

@pytest.mark.parametrize(
    "example_input,expectation",
    [
        (3, does_not_raise(2)),
        (2, does_not_raise(3)),
        (1, does_not_raise(6)),
        (0, pytest.raises(ZeroDivisionError)),
    ],
)
def test_division(example_input, expectation):
    """Test how much I know division."""
    with expectation as e:
        assert (6 / example_input) == e
```
seems to work (though I'd just drop the use of the new name `does_not_raise` as it just confuses IMO).
If one uses e.g. `(1, does_not_raise(5))` it correctly fails.

The only think what I'm not sure about is (though that should be completely irrelevant in the real world:<br>
In the case that the expected output is `pytest.raises(…)`, `e` will be a object of type `<class '_pytest._code.code.ExceptionInfo'>`, right?!

So what if that by bad luck actually compares somehow in the `assert`’s expression **and** no exception is raised? It might give a false positive.