Hey.

Sorry if I miss something obvious and just make noise... O:-)

https://docs.pytest.org/en/7.4.x/how-to/assert.html claims:
> However, if you specify a message with the assertion like this:
> assert a % 2 == 0, "value was odd, should be even"
> then no assertion introspection takes places at all and the message will be simply shown in the traceback.

But when I try this, then introspection **does** seem to happen i.e. I see e.g.:
```
>       assert len(pathname) <= len(escaped_pathname), "foobar"
E       AssertionError: foobar
E       assert 2 <= 1
E        +  where 2 = len('//')
E        +  and   1 = len('/')

test_misc.py:48: AssertionError
```
just with the additional message.

Could it be that this has changed at some point in time but documentation wasn't updated?

Thanks,
Chris.