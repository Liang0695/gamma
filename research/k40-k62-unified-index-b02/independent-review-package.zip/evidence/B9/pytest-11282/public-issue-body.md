I want to manage this INI option 
```
    parser.addini(
        "my_option",
        type="string",
        default=None,
        help="My option",
    )
```

I decide not to include this option in the INI file

I read the value with this code

```
@pytest.fixture(scope='session')
def my_option(request):
    return request.config.getini("my_option")
```

Actual result: The returned value is an empty list

Expected result: None

Tested with pytest 7.4.0 on Linux Mint
