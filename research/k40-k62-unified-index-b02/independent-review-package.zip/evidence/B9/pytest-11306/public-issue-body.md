- [x] a detailed description of the bug or problem you are having
- [x] output of `pip list` from the virtual environment you are using
- [x] pytest and operating system versions
- [x] minimal example if possible

### Bug description and minimal example

https://github.com/flying-sheep/pytest-doctest-import-twice

### Versions

OS: Arch Linux

```nushell
pip list --format=json --exclude-editable | from json | to md --pretty
```

| name       | version |
| ---------- | ------- |
| iniconfig  | 2.0.0   |
| packaging  | 23.1    |
| pip        | 23.2.1  |
| pluggy     | 1.2.0   |
| pytest     | 7.4.0   |
| setuptools | 68.0.0  |
| wheel      | 0.41.0  |