# Description

The option `--override-ini='pythonpath=foo'` may trigger an `AssertionError`.

## Minimal example

Running `pytest --override-ini='pythonpath=foo'` in an *empty* directory fails with
```
Traceback (most recent call last):
  File "/Users/miccoli/.pyenv/versions/3.11.4/envs/_pytest_bug/lib/python3.11/site-packages/_pytest/config/__init__.py", line 1495, in getini
    return self._inicache[name]
           ~~~~~~~~~~~~~~^^^^^^
KeyError: 'pythonpath'

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "/Users/miccoli/.pyenv/versions/_pytest_bug/bin/pytest", line 8, in <module>
    sys.exit(console_main())
             ^^^^^^^^^^^^^^
  File "/Users/miccoli/.pyenv/versions/3.11.4/envs/_pytest_bug/lib/python3.11/site-packages/_pytest/config/__init__.py", line 189, in console_main
    code = main()
           ^^^^^^
  File "/Users/miccoli/.pyenv/versions/3.11.4/envs/_pytest_bug/lib/python3.11/site-packages/_pytest/config/__init__.py", line 147, in main
    config = _prepareconfig(args, plugins)
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/miccoli/.pyenv/versions/3.11.4/envs/_pytest_bug/lib/python3.11/site-packages/_pytest/config/__init__.py", line 328, in _prepareconfig
    config = pluginmanager.hook.pytest_cmdline_parse(
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/miccoli/.pyenv/versions/3.11.4/envs/_pytest_bug/lib/python3.11/site-packages/pluggy/_hooks.py", line 433, in __call__
    return self._hookexec(self.name, self._hookimpls, kwargs, firstresult)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/miccoli/.pyenv/versions/3.11.4/envs/_pytest_bug/lib/python3.11/site-packages/pluggy/_manager.py", line 112, in _hookexec
    return self._inner_hookexec(hook_name, methods, kwargs, firstresult)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/miccoli/.pyenv/versions/3.11.4/envs/_pytest_bug/lib/python3.11/site-packages/pluggy/_callers.py", line 133, in _multicall
    teardown[0].send(outcome)
  File "/Users/miccoli/.pyenv/versions/3.11.4/envs/_pytest_bug/lib/python3.11/site-packages/_pytest/helpconfig.py", line 103, in pytest_cmdline_parse
    config: Config = outcome.get_result()
                     ^^^^^^^^^^^^^^^^^^^^
  File "/Users/miccoli/.pyenv/versions/3.11.4/envs/_pytest_bug/lib/python3.11/site-packages/pluggy/_result.py", line 108, in get_result
    raise exc.with_traceback(exc.__traceback__)
  File "/Users/miccoli/.pyenv/versions/3.11.4/envs/_pytest_bug/lib/python3.11/site-packages/pluggy/_callers.py", line 80, in _multicall
    res = hook_impl.function(*args)
          ^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/miccoli/.pyenv/versions/3.11.4/envs/_pytest_bug/lib/python3.11/site-packages/_pytest/config/__init__.py", line 1075, in pytest_cmdline_parse
    self.parse(args)
  File "/Users/miccoli/.pyenv/versions/3.11.4/envs/_pytest_bug/lib/python3.11/site-packages/_pytest/config/__init__.py", line 1425, in parse
    self._preparse(args, addopts=addopts)
  File "/Users/miccoli/.pyenv/versions/3.11.4/envs/_pytest_bug/lib/python3.11/site-packages/_pytest/config/__init__.py", line 1327, in _preparse
    self.hook.pytest_load_initial_conftests(
  File "/Users/miccoli/.pyenv/versions/3.11.4/envs/_pytest_bug/lib/python3.11/site-packages/pluggy/_hooks.py", line 433, in __call__
    return self._hookexec(self.name, self._hookimpls, kwargs, firstresult)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/miccoli/.pyenv/versions/3.11.4/envs/_pytest_bug/lib/python3.11/site-packages/pluggy/_manager.py", line 112, in _hookexec
    return self._inner_hookexec(hook_name, methods, kwargs, firstresult)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/miccoli/.pyenv/versions/3.11.4/envs/_pytest_bug/lib/python3.11/site-packages/pluggy/_callers.py", line 155, in _multicall
    return outcome.get_result()
           ^^^^^^^^^^^^^^^^^^^^
  File "/Users/miccoli/.pyenv/versions/3.11.4/envs/_pytest_bug/lib/python3.11/site-packages/pluggy/_result.py", line 108, in get_result
    raise exc.with_traceback(exc.__traceback__)
  File "/Users/miccoli/.pyenv/versions/3.11.4/envs/_pytest_bug/lib/python3.11/site-packages/pluggy/_callers.py", line 80, in _multicall
    res = hook_impl.function(*args)
          ^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/miccoli/.pyenv/versions/3.11.4/envs/_pytest_bug/lib/python3.11/site-packages/_pytest/python_path.py", line 15, in pytest_load_initial_conftests
    for path in reversed(early_config.getini("pythonpath")):
                         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/miccoli/.pyenv/versions/3.11.4/envs/_pytest_bug/lib/python3.11/site-packages/_pytest/config/__init__.py", line 1497, in getini
    self._inicache[name] = val = self._getini(name)
                                 ^^^^^^^^^^^^^^^^^^
  File "/Users/miccoli/.pyenv/versions/3.11.4/envs/_pytest_bug/lib/python3.11/site-packages/_pytest/config/__init__.py", line 1540, in _getini
    assert self.inipath is not None
           ^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError
```

## Output of `pip list` and enviornment

```
Package    Version
---------- -------
iniconfig  2.0.0
packaging  23.1
pip        23.2.1
pluggy     1.2.0
pytest     7.4.0
setuptools 65.5.0
```

Run on `macOS-13.2.1-x86_64-i386-64bit`, but same problem also on linux.

## Context

I stumbled in this error while building a python package for Arch: instead of using
```bash
check(){
    cd "$_name-$pkgver"
    PYTHONPATH=src pytest
}
```
I tried 
```bash
check(){
    cd "$_name-$pkgver"
    pytest -o pythonpath=src
}
```
which fails with the above traceback.

I replicated the problem on a MacOs stripped down venv just to be sure that it is not related to the ArchLinux build env, which is quite complicated.
