```py
from pytest import asdfasdf
```
no error from mypy:
```
>mypy main.py
Success: no issues found in 1 source file
```

i'm not sure what the purpose of this `__getattr__` method is, but it should probably be inside an `if not TYPE_CHECKING` block to avoid this issue:
```py
from typing import TYPE_CHECKING:

if not TYPE_CHECKING:
    def __getattr__(name: str) -> object:
        if name == "Instance":
            # The import emits a deprecation warning.
            from _pytest.python import Instance
    
            return Instance
        raise AttributeError(f"module {__name__} has no attribute {name}")
```