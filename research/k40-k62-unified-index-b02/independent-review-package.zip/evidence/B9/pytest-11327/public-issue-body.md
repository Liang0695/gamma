the update-plugin-list job has been failing for about a month

https://github.com/pytest-dev/pytest/actions/runs/5914257523/job/16039386893

```
 Traceback (most recent call last):
  File "scripts/update-plugin-list.py", line 65, in <module>
    ) -> OriginalResponse | CachedResponse:
TypeError: unsupported operand type(s) for |: 'type' and 'type'
```