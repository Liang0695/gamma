As discussed in https://github.com/pytest-dev/pytest/issues/11346#issuecomment-1694335296, the feature could be made clearer in the docs:

https://docs.pytest.org/en/stable/how-to/cache.html#behavior-when-no-tests-failed-in-the-last-run