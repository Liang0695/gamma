when test fails and it's teardown is failing the data add with `record_property` isn't attached to the test failure, but only to the teardown failure

example such run with `pytest  --junit-xml=junit.xml`:
```
import pytest

@pytest.fixture(scope="function", autouse=True)
def fixture_add_props(record_property):
    record_property('split_name', "something_coming_form_env")

class TestSomthing:
    def test_pass(self):
        pass

    def test_fail(self):
        raise Exception("failed")

    def test_pass_teardown_fail(self, request: pytest.FixtureRequest):
        def fin():
            raise Exception("failed teardown")
        request.addfinalizer(fin)
        
    def test_fail_test_and_teardown(self, request: pytest.FixtureRequest):
        def fin():
            raise Exception("failed teardown")
        request.addfinalizer(fin)

        raise Exception("failed")
```


I would expect both testcases to have properties that was attached to the test