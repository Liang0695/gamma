<!--
Thanks for suggesting a feature!

Quick check-list while suggesting features:
-->

#### What's the problem this feature will solve?
When writing async unit-tests, it is extremely easy to forget to install the pytest-async extension and end up ignoring the futures.  
This can cause unexpected silence:

```python
async def test_should_fail_but_doesnt():
    assert False
```

This passes if pytest-async is not installed.  Instead, I'd like to propose we make this fail with a nice message indicating that you need too install python-async.

#### Describe the solution you'd like

I'd like to inspect tests to see if they return a future.   If they return a future, and pytest-async is not installed i'd like to error out and tell users to install it.

#### Alternative Solutions

Ignore the tests.

#### Additional context

I've been bit by this once~ know another team member of mine who has also been bitten by this.
I'm happy to contribute this.