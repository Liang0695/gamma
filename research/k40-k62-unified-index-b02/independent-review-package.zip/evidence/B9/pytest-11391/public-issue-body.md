
https://github.com/pytest-dev/pytest/blob/9c8937b4800c72bb511a45f4548f0c58823ec30b/doc/en/reference/plugin_list.rst  lists a couple of plugins with the same description:

```
   :pypi:`pytest-check-requirements`                A package to prevent Dependency Confusion attacks against Yandex.                                                                                                                                         Feb 10, 2023    N/A                    N/A
   :pypi:`pytest-diffeo`                            A package to prevent Dependency Confusion attacks against Yandex.                                                                                                                                         Feb 10, 2023    N/A                    N/A
   :pypi:`pytest-factor`                            A package to prevent Dependency Confusion attacks against Yandex.                                                                                                                                         Feb 10, 2023    N/A                    N/A
   :pypi:`pytest-star-track-issue`                  A package to prevent Dependency Confusion attacks against Yandex.                                                                                                                                         Feb 10, 2023    N/A                    N/A
   :pypi:`pytest-xskynet`                           A package to prevent Dependency Confusion attacks against Yandex.                                                                                                                                         Feb 10, 2023    N/A                    N/A
```
each of these links to these strange, minimal pypi listings with 
> This is a security placeholder package. If you want to claim this name for legitimate purposes, please contact us at ...

Are these legitimate plugins that should be listed in the pytest docs?