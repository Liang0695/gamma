<!--
Thanks for submitting an issue!

Quick check-list while reporting bugs:
-->

I am seeing an issue when passing a very long command-line argument to pytest. It fails to run with the following error:

```
INTERNALERROR>   File "/venv/lib/python3.11/site-packages/_pytest/main.py", line 333, in pytest_collection
INTERNALERROR>     session.perform_collect()
INTERNALERROR>   File "/venv/lib/python3.11/site-packages/_pytest/main.py", line 638, in perform_collect
INTERNALERROR>     fspath, parts = resolve_collection_argument(
INTERNALERROR>                     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^
INTERNALERROR>   File "/venv/lib/python3.11/site-packages/_pytest/main.py", line 889, in resolve_collection_argument
INTERNALERROR>   File "/venv/lib/python3.11/site-packages/_pytest/main.py", line 889, in resolve_collection_argument
INTERNALERROR>     if not fspath.exists():
INTERNALERROR>            ^^^^^^^^^^^^^^^
INTERNALERROR>   File "/usr/local/lib/python3.11/pathlib.py", line 1235, in exists
INTERNALERROR>     self.stat()
INTERNALERROR>   File "/usr/local/lib/python3.11/pathlib.py", line 1013, in stat
INTERNALERROR>     return os.stat(self, follow_symlinks=follow_symlinks)
INTERNALERROR>            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
INTERNALERROR> OSError: [Errno 36] File name too long: '/pwd/tests/very,long,comma-seperated,value,for,long_list'
```

Pytest version:
Tested with 7.3.2 and 7.4.1

pip list output:
```Package               Version
--------------------- ---------
allure-pytest         2.13.2
allure-python-commons 2.13.2
ansi2html             1.8.0
attrs                 23.1.0
boto3                 1.28.40
botocore              1.31.40
certifi               2023.7.22
chardet               5.2.0
charset-normalizer    3.2.0
click                 8.1.3
contourpy             1.0.7
cycler                0.11.0
datadog               0.45.0
execnet               1.9.0
filelock              3.12.0
fonttools             4.39.4
gitdb                 4.0.10
GitPython             3.1.31
idna                  3.4
iniconfig             2.0.0
Jinja2                3.1.2
jmespath              1.0.1
kiwisolver            1.4.4
markdown-it-py        2.2.0
MarkupSafe            2.1.3
matplotlib            3.7.1
mdurl                 0.1.2
numpy                 1.24.3
packaging             23.1
pandas                1.5.3
Pillow                9.5.0
pip                   22.3.1
pluggy                1.0.0
py                    1.11.0
Pygments              2.15.1
pyparsing             3.0.9
pytest                7.4.1
pytest-html           4.0.0
pytest-metadata       2.0.4
pytest-xdist          3.3.1
python-dateutil       2.8.2
pytz                  2022.7.1
requests              2.31.0
rich                  13.3.5
s3transfer            0.6.2
setuptools            65.5.0
six                   1.16.0
smmap                 5.0.0
urllib3               1.26.16
```

Example usage:

conftest.py:
```
import pytest

def pytest_addoption(parser):
    parser.addoption("--long-list", dest="long_list", action="store", default="all", help="List of things")

@pytest.fixture(scope="module")
def specified_feeds(request):
    list_string = request.config.getoption("--long-list")
    return list_string.split(',')
```

Invocation:
`pytest /test_my_thing.py --long-list a,b,c,d,e,f`

Note: the actual length of the string passed to `--long-list` is 396 characters

This seems to be similar to #10169