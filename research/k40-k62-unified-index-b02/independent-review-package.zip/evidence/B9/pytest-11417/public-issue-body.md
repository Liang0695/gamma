<!--
Thanks for submitting an issue!

Quick check-list while reporting bugs:
-->

- [ ] a detailed description of the bug or problem you are having
- [ ] output of `pip list` from the virtual environment you are using
- [ ] pytest and operating system versions
- [ ] minimal example if possible


I've bracketed the exception to `pytest==7.4.2`:


with:
```console
$ cat test_debug_pytest.py
def test_my_test():
    assert True
$ cat pyproject.toml
[tool.pytest.ini_options]
addopts = "-ra --import-mode=importlib"
$ cat __init__.py

$ pytest test_debug_pytest.py
================================================================================ test session starts =================================================================================
platform linux -- Python 3.8.11, pytest-7.4.2, pluggy-0.13.1
rootdir: /mnt/c/Users/.../test
configfile: pyproject.toml
plugins: forked-1.3.0, notebook-0.6.1, mock-3.6.1, anyio-3.3.0, subtests-0.9.0, timeout-2.1.0, xdist-2.3.0, dash-2.7.0, cov-4.0.0, flaky-3.7.0, asyncio-0.21.0
asyncio: mode=strict
collected 1 item

test_debug_pytest.py E                                                                                                                                                         [100%]

======================================================================================= ERRORS =======================================================================================
___________________________________________________________________________ ERROR at setup of test_my_test ___________________________________________________________________________

self = PurePosixPath('.'), suffix = '.py'

    def with_suffix(self, suffix):
        """Return a new path with the file suffix changed.  If the path
        has no suffix, add given suffix.  If the given suffix is an empty
        string, remove the suffix from the path.
        """
        f = self._flavour
        if f.sep in suffix or f.altsep and f.altsep in suffix:
            raise ValueError("Invalid suffix %r" % (suffix,))
        if suffix and not suffix.startswith('.') or suffix == '.':
            raise ValueError("Invalid suffix %r" % (suffix))
        name = self.name
        if not name:
>           raise ValueError("%r has an empty name" % (self,))
E           ValueError: PurePosixPath('.') has an empty name

/home/me/miniconda3/envs/aq/lib/python3.8/pathlib.py:872: ValueError
============================================================================== short test summary info ===============================================================================
ERROR test_debug_pytest.py::test_my_test - ValueError: PurePosixPath('.') has an empty name
================================================================================== 1 error in 0.14s ==================================================================================
```
with no `conftest.py`.

