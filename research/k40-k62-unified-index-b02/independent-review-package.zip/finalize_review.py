import collections, hashlib, json, pathlib, re, shutil, zipfile
from verify_source import OUT, ROOT, rows, idx, idxrows, raw_nodes, source_zips, expected, gate_report, sha, load, write

byid={r['task_id']:r for r in rows}
def ident(n): return 'pytest-dev/pytest#'+str(n)
def body(n):
 r=byid[ident(n)]; z=source_zips[int(r['batch'][1:])]
 return z.read(f'pytest-{n}/public-issue-body.md').decode().replace('\r','')
def evidence(n,needle):
 r=byid[ident(n)]
 lines=body(n).splitlines()
 found=[{'line':i+1,'excerpt':l[:450]} for i,l in enumerate(lines) if needle.lower() in l.lower()]
 assert found,(n,needle)
 return {'task_id':ident(n),'member':f'pytest-{n}/public-issue-body.md','sha256':next(e['sha256'] for e in r['evidence'] if e['member'].endswith('public-issue-body.md')),'locations':found}

edges=[]; label_errors=[]
for r in rows:
 for ordinal,ref in enumerate(r['refs'],1):
  num=int(re.search(r'#(\d+)',ref).group(1)); target=ident(num)
  edge={'edge_id':f"{r['task_id']}/ref-{ordinal}",'source':r['task_id'],'original_ref':ref,'target_number':num,'target_kind':'ISSUE','target':target,'classification':'TOPICAL_ADJACENCY_ONLY','family_root':'UNKNOWN','backport':'NOT_ESTABLISHED','clearance':False,'evidence':[],'missing':[]}
  if ref.startswith('unclassified'):
   meanings={10482:('PR','PR #10482'),10618:('ISSUE','issue #10618'),9834:('DISCUSSION','discussion #9834'),11115:('ISSUE_OR_UNTYPED_REPORT_REFERENCE','another regression (#11115)'),10169:('UNTYPED_HASH_REFERENCE','similar to #10169'),10758:('PR','PR #10758'),10988:('PR','since #10988'),2224:('UNTYPED_HASH_REFERENCE','see #2224'),9962:('UNTYPED_HASH_REFERENCE','#9962 proposes')}
   kind,needle=meanings[num]; edge['target_kind']=kind; edge['evidence'].append(evidence(int(r['task_id'].split('#')[1]),needle))
   edge['classification']={'PR':'PUBLIC_OPENING_NAMES_PRIOR_PR','ISSUE':'PUBLIC_OPENING_NAMES_RELATED_ISSUE','DISCUSSION':'PUBLIC_OPENING_NAMES_DISCUSSION'}.get(kind,'PUBLIC_OPENING_REFERENCE_TYPE_OR_CAUSALITY_UNRESOLVED')
   if kind=='PR':
    owners=[x for x in rows if x['closing_pr']==num]
    edge['target']='https://github.com/pytest-dev/pytest/pull/'+str(num)
    edge['pinned_pr_closes']=[x['task_id'] for x in owners]
   elif kind=='DISCUSSION': edge['target']='https://github.com/pytest-dev/pytest/discussions/'+str(num)
  tr=idxrows.get(target) if edge['target_kind']=='ISSUE' else None
  if tr:
   edge['pinned_identity_comparison']={
    'source_closing_pr':r['closing_pr'],'target_closing_pr_url':tr['closing_pr_url'],
    'same_closing_pr':r['closing_pr']==int(tr['closing_pr_url'].rsplit('/',1)[1]),
    'same_merge':r['merge_commit']==tr['merge_commit'],
    'same_base':r['base_commit']==tr['base_commit'],
    'same_tree':r['base_tree']==tr['base_tree'],
    'same_archive':r['archive_sha256']==tr['source_archive_sha256']}
   if not ref.startswith('unclassified'):
    edge['classification']='TOPICAL_ONLY_DISTINCT_PINNED_IDENTITIES'
   actual_batch=tr['evidence']['batch']; stated=re.search(r'\(B(\d+)',ref)
   if stated and int(stated.group(1))!=int(re.search(r'B0*(\d+)$',actual_batch).group(1)):
    label_errors.append(dict(edge_id=edge['edge_id'],original_ref=ref,actual_batch=actual_batch))
   edge['evidence'].append({'package':'k40-k62-unified-index-b09-b11.zip','sha256':expected['k40-k62-unified-index-b09-b11.zip'],'member':'manifest.json','pointer':f"records[repo_issue={target}]"})
  if num==10618 and r['task_id']==ident(11233):
   batch,n,node=raw_nodes[num]
   edge['cached_target_identity']={'batch':f'B{batch}','member':n,'title':node['title'],'closer':None}
   edge['classification']='REPORTER_ASSERTED_SAME_OUTPUT_PROBLEM; NO_CACHED_CLOSER_FOR_TARGET'
  edge['missing']=[f"Existing family/root/backport disposition for {r['task_id']} and {edge['target']}; distinct event identities alone do not prove independent root."]
  if not tr and edge['target_kind']!='PR':
   edge['missing'].append(f"Existing typed identity/closure metadata for {edge['target']}; no endpoint expansion performed.")
  edges.append(edge)

# Explicit new links discovered in the provided public openings; no target body is fetched.
reported=[
 (11239,11028,'REPORTER_BISECTED_TO_PINNED_CLOSING_PR',11041,'bisected the issue'),
 (11028,10743,'REPORTER_SUSPECTS_REGRESSION_FROM_PINNED_CLOSING_PR',10758,'PR #10758'),
 (11104,10987,'REPORTER_SUSPECTS_REGRESSION_FROM_PINNED_CLOSING_PR',10988,'since #10988'),
]
new=[]
for a,b,kind,pr,needle in reported:
 assert byid[ident(b)]['closing_pr']==pr
 new.append(dict(source=ident(a),target=ident(b),classification=kind,pr=pr,causal_claim='PUBLIC_REPORT_ONLY; code causality not independently reproduced',same_family='HOLD_PENDING_ROOT_REVIEW',root='UNKNOWN',backport='NOT_ESTABLISHED',evidence=[evidence(a,needle)],pinned_closer=next(e for e in byid[ident(b)]['evidence'] if e['member'].endswith('/closure-evidence.json'))))

lineage=[(11137,'pytest-dev/pytest#7777','extracted verbatim'),(11013,'pytest-dev/pytest#11006','Originally posted'),(11354,'pytest-dev/pytest#11346','As discussed'),(11356,'pytest-dev/pytest#11343','Issue with mypy'),(10903,'pytest-dev/pytest/discussions/10895','Originally posted'),(10710,'pytest-dev/pytest-reportlog#19','Initial feature request'),(10865,'pytest-dev/pytest#9288','Related to')]
for a,t,needle in lineage:
 new.append(dict(source=ident(a),target=t,classification='PUBLIC_OPENING_ORIGIN_OR_RELATED_REFERENCE',root='UNKNOWN',backport='NOT_ESTABLISHED',clearance=False,evidence=[evidence(a,needle)],missing=[f'Existing metadata describing lineage/root for {ident(a)} and {t}; opening provenance is not an independent-root decision.']))

# The excluded peer is examined through cached closure metadata only.
b,n,node=raw_nodes[10871]; c=node['timelineItems']['nodes'][0]['closer']; r=byid[ident(10870)]
assert c['number']==r['closing_pr'] and c['mergeCommit']['oid']==r['merge_commit']
assert c['mergeCommit']['parents']['nodes'][0]['oid']==r['base_commit']
assert c['mergeCommit']['parents']['nodes'][0]['tree']['oid']==r['base_tree']
new.append(dict(source=ident(10870),target=ident(10871),classification='SHARED_DIRECT_CLOSURE_MERGE_BASE_TREE_CONFIRMED',root_credit_increment=0,excluded_peer_preserved=True,evidence=[{'package':'KAGGLE-50-pytest-source-batch-b11.zip','member':n,'sha256':sha(source_zips[11].read(n)),'pointer':'data.repository.i10871.timelineItems.nodes[0].closer'}],note='No second archive exists for excluded peer; shared source identity follows the same fixed base, not a separately verified peer archive hash.'))

for edge in edges:
 if edge['source']==ident(10743) and edge['target']==ident(11239):
  edge['classification']='REPORTED_REGRESSION_CHAIN_WITH_PINNED_PR_IDENTITIES'
  edge['reported_chain']=[ident(10743),'PR#10758',ident(11028),'PR#11041',ident(11239)]
  edge['evidence'] += [evidence(11028,'PR #10758'),evidence(11239,'bisected the issue')]
  edge['missing']=['Existing reviewer root disposition for #10743/#11028/#11239; public reporters link sequential regressions, but this does not verify fix causality or backport identity. Keep the three in one conservative family-review hold until resolved.']

doc={11258:'Parametrizing conditional raising documentation example, with proposed working example in opening',11265:'Assertion documentation disagrees with observed introspection; opening requests documentation correction',11354:'Clarify --last-failed-no-failures documentation; origin #11346',11391:'Plugin-list documentation asks about security-placeholder PyPI listings, not a demonstrated runtime defect',11065:'Use pytestconfig rather than request in config.cache documentation',11091:'Document --junitxml/--junit-xml alias consistency',10690:'Document CI and BUILD_NUMBER environment variables',10782:'Packaging documentation example lacks version and includes proposed corrected TOML'}
tools={11327:'update-plugin-list CI job annotation failure',11356:'Repository pre-commit flake8 self-check fails on EncodingWarning',11157:'Repository tox warning envvar configuration',10630:'Repository self-test expected output changes under pygments 2.14',10870:'PyPI/GitHub publishing workflow, no standalone coding acceptance supplied'}
implementation={
11218:('propose making','Opening proposes abstract FixtureRequest plus TopRequest subclass'),
11223:('helper function','Opening supplies exception/notes matching helper'),
11325:('if not TYPE_CHECKING','Opening supplies TYPE_CHECKING guard implementation'),
10940:('def _pad_wrap_message','Opening supplies implementation and a test'),
11068:('when it should check','Opening explicitly names Module-to-File implementation change'),
11081:('move this check','Opening supplies internal implementation restructuring'),
11137:('initial implementation','Opening links working POC and specifies class/path restructuring; link not opened'),
10604:('exist_ok=True','Opening supplies concrete makedirs change'),
10617:('def pytest_assertrepr_compare','Opening supplies comparison-formatting implementation'),
10654:('def maybe_raises','Opening supplies proposed maybe_raises implementation'),
10701:('if w.category is cls','Opening supplies replacement comparison'),
10710:('TestReport.from_item_and_call','Opening prescribes copying start/stop fields from CallInfo'),
10765:('and sys.platform !=','Opening supplies precise platform guard'),
10782:('### Fix','Opening supplies corrected project configuration'),
}
for r in rows:
 num=int(r['task_id'].split('#')[1]); content=[]
 if num in doc: content.append(dict(kind='DOCUMENTATION_SCOPE',observation=doc[num]))
 if num in tools: content.append(dict(kind='DEVELOPER_INFRASTRUCTURE_SCOPE',observation=tools[num]))
 if num in implementation:
  needle,description=implementation[num]
  content.append(dict(kind='OPENING_IMPLEMENTATION_OR_POC_EXPOSURE',observation=description,evidence=evidence(num,needle)))
 if num==11306: content.append(dict(kind='REPRODUCTION_EXTERNALLY_REFERENCED',observation='Opening points to flying-sheep/pytest-doctest-import-twice; no minimal reproduction bytes supplied inline and external repo not opened'))
 if num==10896: content.append(dict(kind='REDUCER_NOT_SUPPLIED',observation='Opening reports Windows performance timings and says reduction/bisection still planned'))
 r['public_opening_observations']=content
 r['review_disposition']='SOURCE_CHAIN_VERIFIED_PURPOSE_AND_FAMILY_NOT_RELEASED'
 r['family_review_edge_ids']=[e['edge_id'] for e in edges if e['source']==r['task_id']]
 r['additional_relations']=[{'target':e['target'],'classification':e['classification']} for e in new if e['source']==r['task_id'] or e['target']==r['task_id']]
 r['unresolved']=[dict(owner='1b existing index/custody metadata',item=f"No task-level dev/sealed/old-exposure exclusion and source-purpose decision for {r['task_id']} at base {r['base_commit']} / body {next(e['sha256'] for e in r['evidence'] if e['member'].endswith('public-issue-body.md'))}. Existing exact-ID lists do not establish family non-overlap.")]
 for e in edges:
  if e['source']==r['task_id']: r['unresolved'].append({'edge_id':e['edge_id'],'item':e['missing']})
 if content: r['unresolved'].append({'owner':'1b existing qualification/scope records','item':f"Disposition of the recorded {', '.join(x['kind'] for x in content)} for {r['task_id']}; keep original opening immutable, do not silently redact or assign train role."})
 r['gate_binding_note']='Independent review binds actual K62 v24 ZIP members; inherited batch SHA claims differ. See gate-provenance-review.json. No gate is removed.'

# Compare incoming identity attributes without re-reviewing earlier candidates.
duplicates=[]
for r in rows:
 for old in idx['records']:
  if old['repo_issue']==r['task_id'] or 'base_commit' not in old or 'source_archive_sha256' not in old: continue
  if old.get('merge_commit')==r['merge_commit'] or (old['base_commit']==r['base_commit'] and old['source_archive_sha256']==r['archive_sha256']):
   duplicates.append({'source':r['task_id'],'peer':old['repo_issue']})
assert not duplicates

write('review-manifest.json',{'schema':'k68-independent-source-family-review/1','reviewer':'082bbef2-a827-4e50-bcb2-57ef1f383924','input_index_commit':'0bafa464239358db303c5ce0f2001a012526fbc7','input_index_sha256':expected['k40-k62-unified-index-b09-b11.zip'],'scope':'B9-B11 only; earlier rows are used as immutable identity pointers, not re-reviewed','records':rows})
write('family-review-ledger.json',{'schema':'k68-family-reference-review/1','reviewed_entries':len(edges),'unique_original_strings':len(set(e['original_ref'] for e in edges)),'independent_root_clearances':0,'entries':edges,'additional_existing_evidence_relations':new,'batch_label_corrections':label_errors,'identity_duplicates_among_incoming_and_existing_index':duplicates,'known_hold':'pytest-dev/pluggy#140 <-> pytest-dev/pytest#2639 PRESERVED','no_backport_or_clearance_inferred':True})
counts={'metadata_identities':364,'material_identities':344,'pinned_source_candidates':320,'source_ready':85,'deployable':0,'training_approved':0}
summary={'coverage':{'B9':20,'B10':20,'B11':20,'total_source_chains_verified':60,'related_reference_entries_reviewed':len(edges),'unique_reference_strings':len(set(e['original_ref'] for e in edges))},'source_ready_increment':0,'deployable_increment':0,'training_approved_increment':0,'global_counts_unchanged':counts,'new_independent_root_credit':0,'content_observation_counts':dict(collections.Counter(o['kind'] for r in rows for o in r['public_opening_observations'])),'gate_sha_claim_mismatches':len(gate_report['claims_mismatch']),'reference_batch_label_errors':label_errors,'family_classifications':dict(collections.Counter(e['classification'] for e in edges)),'limits':['Offline provenance binding from fixed cached responses; no fresh upstream queries','No whole-tree recomputation; archive SHA/PAX and metadata tree OID cross-check only','No PR body/diff/fix, repository test file contents, hidden evaluation material, tests, deployments, GPU, AA or 107','No role/split/actor/test-acceptance/training elevation'],'handoff':{'owner':'1b62b5f5-e26f-4f8a-b5bf-dcbeb4412cad','action':'Append review ledger alongside existing index with exact evidence SHAs; preserve all historical bytes. Rebind gate provenance by additive correction. Supply only existing missing identity/family/purpose records. No recollection, B12 restart, or upstream clearance override.'}}
write('summary.json',summary)
# Copy only approved non-answer evidence into standalone review artifact.
for batch,z in source_zips.items():
 for n in z.namelist():
  allowed=(n.endswith('/public-issue-body.md') or n.endswith('/public-issue.json') or n.endswith('/closure-evidence.json') or n.endswith('/manifest.json') or n.endswith('/LICENSE') or n.endswith('/pyproject.toml') or n.endswith('/tox.ini') or re.match(r'evidence/pytest-cursor\d+-closures(?:-request)?.json$',n) or re.match(r'evidence/pytest-b\d+-selected-issues(?:-query.txt|.json)$',n) or n=='evidence/k62-gate-review.json' or n=='SHA256SUMS.txt')
  if allowed:
   p=OUT/'evidence'/f'B{batch}'/n; p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(z.read(n))
for n in ['manifest.json','counts.json','sha256sums.txt']:
 p=OUT/'evidence'/'input-index'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(__import__('verify_source').iz.read(n))
for name in ['verify_source.py','finalize_review.py']:
 shutil.copyfile(ROOT/name,OUT/name)
print(json.dumps(summary,ensure_ascii=False,indent=2))
