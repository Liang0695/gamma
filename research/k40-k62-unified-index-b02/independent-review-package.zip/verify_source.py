"""Offline source evidence audit. No execution/import of candidate code or test-file reads."""
import collections, hashlib, io, json, pathlib, re, tarfile, zipfile

ROOT=pathlib.Path(__file__).resolve().parent
OUT=ROOT/'review'
OUT.mkdir(exist_ok=True)
def sha(b): return hashlib.sha256(b).hexdigest()
def load(z,n): return json.loads(z.read(n).decode('utf-8-sig'))
def write(n,obj): (OUT/n).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
expected={
 'k40-k62-unified-index-b09-b11.zip':'ec93e4c6a4e4e33b2e9e34d2113213a0e8ebf3ce546524cd4fc144253581038a',
 'KAGGLE-62-consolidated-v24.zip':'fb29a18b319b332b70c0d594576395fb922a02e07caa524ed36eed4cbe7058a9',
 'KAGGLE-50-pytest-source-batch-b9.zip':'7a565ee94aacc60a76dc94f7af6e926ac1a7356c629097b4531ef1a55aff6330',
 'KAGGLE-50-pytest-source-batch-b10.zip':'6a09c1169dfd4a733d48eb78a7bdb9ee573d7ff5ed7cee7e12d09ab7aae5ed9c',
 'KAGGLE-50-pytest-source-batch-b11.zip':'bc26ba2814fbcbdb90750d161e6992414f694e294e066d30e8559f7125fb86cf',
}
inputs=[]
for name,h in expected.items():
 p=ROOT/'inputs'/name
 actual=sha(p.read_bytes()); assert actual==h,(name,actual)
 inputs.append(dict(filename=name,sha256=h,bytes=p.stat().st_size))
iz=zipfile.ZipFile(ROOT/'inputs/k40-k62-unified-index-b09-b11.zip')
idx=load(iz,'manifest.json'); idxrows={r['repo_issue']:r for r in idx['records']}
gz=zipfile.ZipFile(ROOT/'inputs/KAGGLE-62-consolidated-v24.zip')
gate=load(gz,'dedup-and-gates.json'); prescreen=load(gz,'body-prescreen-exclusions.json')
gateids=set(gate['effective_queue_exclusion_ids']); bodyids=set(prescreen['ids'])
gate_report={'upstream_zip_sha256':expected[pathlib.Path(gz.filename).name], 'members':[],'claims_mismatch':[]}
for n in ('dedup-and-gates.json','body-prescreen-exclusions.json'):
 h=sha(gz.read(n)); item=next(x for x in load(gz,'SHA256SUMS.json') if x['file']==n)
 assert h==item['sha256']
 gate_report['members'].append(dict(member=n,sha256=h,bytes=len(gz.read(n))))
 (OUT/n).write_bytes(gz.read(n))

rows=[]; raw_nodes={}; ledger_results=[]; source_zips={}
for batch in (9,10,11):
 z=zipfile.ZipFile(ROOT/f'inputs/KAGGLE-50-pytest-source-batch-b{batch}.zip'); source_zips[batch]=z
 entries=[]
 for line in z.read('SHA256SUMS.txt').decode('utf-8-sig').splitlines():
  if not line.strip(): continue
  h,n=line.split(None,1); n=n.lstrip('* ')
  actual=sha(z.read(n)); assert h.lower()==actual,(batch,n,h,actual)
  entries.append({'member':n,'sha256':actual})
 assert set(x['member'] for x in entries)==set(z.namelist())-{'SHA256SUMS.txt'}
 ledger_results.append(dict(batch=f'B{batch}',verified_members=len(entries),all_match=True))
 gclaim=load(z,'evidence/k62-gate-review.json')['k62_v24']
 for field,n in [('dedup_and_gates_sha256','dedup-and-gates.json'),('body_prescreen_sha256','body-prescreen-exclusions.json')]:
  if gclaim[field].lower()!=sha(gz.read(n)):
   gate_report['claims_mismatch'].append(dict(batch=f'B{batch}',member=n,claimed_sha256=gclaim[field].lower(),actual_sha256=sha(gz.read(n))))
 closure_files=[n for n in z.namelist() if re.match(r'evidence/pytest-cursor\d+-closures.json$',n)]
 closers={}
 for n in closure_files:
  req=load(z,n.replace('-closures.json','-closures-request.json'))['query']
  assert 'itemTypes: [CLOSED_EVENT]' in req and 'parents(first: 2)' in req
  data=load(z,n); assert not data.get('errors'),data.get('errors')
  for node in data['data']['repository'].values():
   if node is None: continue
   raw_nodes[node['number']]=(batch,n,node)
   closers[node['number']]=(n,node)
 bodyfile=f'evidence/pytest-b{batch}-selected-issues.json'
 bodyraw=load(z,bodyfile)['data']['repository']
 for n in z.namelist():
  if not n.endswith('/manifest.json'): continue
  m=load(z,n); folder=n.rsplit('/',1)[0]; num=int(folder.split('-')[1]); r=idxrows[m['task_id']]
  checks={}; refs=[]
  def check(k,v):
   checks[k]=bool(v)
   if not v: raise ValueError((m['task_id'],k))
  body=z.read(folder+'/public-issue-body.md'); public=load(z,folder+'/public-issue.json')
  raw=bodyraw['i'+str(num)]
  check('body_raw_graphql_exact_bytes',raw['body'].encode('utf-8')==body)
  check('body_sha',sha(body)==m['public_issue_body_utf8_sha256'].lower()==public['body_utf8_sha256'].lower()==r['problem_text_sha256'])
  check('public_identity_title_url',raw['number']==public['number']==num and raw['title']==public['title']==m['title'] and raw['url']==public['url']==m['public_issue_url'])
  check('body_length',len(body)==m['public_issue_body_utf8_bytes']==public['body_utf8_bytes'])
  clfile,node=closers[num]
  cl=load(z,folder+'/closure-evidence.json')
  events=[e['closer'] for e in node['timelineItems']['nodes'] if e.get('closer') and e['closer'].get('__typename')=='PullRequest' and e['closer']['number']==m['closing_pr']]
  check('direct_closure_unique_match',len(events)==1)
  event=events[0]; parent=event['mergeCommit']['parents']['nodes'][0]
  check('closer_same_repo_merged',event['repository']['nameWithOwner']=='pytest-dev/pytest' and bool(event['mergedAt']) and event['url']==m['closing_pr_url']==cl['closer_pr_url']==r['closing_pr_url'])
  check('merge_identity',event['mergeCommit']['oid']==m['merge_commit']==cl['merge_commit_oid']==r['merge_commit'] and event['mergedAt']==m['merged_at']==cl['merged_at'])
  check('first_parent_identity',parent['oid']==m['broken_base_first_parent']==cl['merge_first_parent_oid']==r['base_commit'])
  check('tree_metadata_identity',parent['tree']['oid']==m['broken_base_tree']==m['base_tree_from_graphql']==cl['merge_first_parent_tree_oid']==r['base_tree'])
  archive=z.read(folder+'/base.tar.gz')
  check('archive_sha_and_length',sha(archive)==m['base_source_sha256'].lower()==r['source_archive_sha256'] and len(archive)==m['base_source_bytes']==r['source_archive_bytes'])
  check('archive_url_pin',m['base_source_url']=='https://codeload.github.com/pytest-dev/pytest/tar.gz/'+parent['oid'])
  with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
   members=tar.getmembers(); base='pytest-'+parent['oid']; paths={x.name:x for x in members}
   check('archive_pax_commit',tar.pax_headers.get('comment')==parent['oid'])
   check('archive_root_and_count',all(x.name==base or x.name.startswith(base+'/') for x in members) and len(members)==m['archive_member_count'])
   lic=z.read(folder+'/LICENSE'); tl=tar.extractfile(paths[base+'/LICENSE']).read()
   check('license_original_bytes',lic==tl and sha(lic)==m['historical_license_sha256'].lower()==r['historical_license_sha256'])
   check('license_mit_notice','The MIT License (MIT)' in lic.decode() and 'The above copyright notice and this permission notice shall be included' in lic.decode())
   dep=[]
   for d in m['build_dependency_declarations']:
    path=d['path'].removeprefix('./'); member=base+'/'+path
    if d['status']=='PRESENT':
     b=z.read(folder+'/'+path); original=tar.extractfile(paths[member]).read()
     check('declaration_'+path,b==original and sha(b)==d['sha256'].lower() and len(b)==d['bytes'])
     dep.append(dict(path=path,sha256=sha(b),bytes=len(b)))
    else: check('absent_'+path,member not in paths)
   inv=load(z,folder+'/public-test-paths.json')
   check('inventory_paths_exist',len(inv['test_paths'])==inv['test_path_count'] and all(base+'/'+p in paths for p in inv['test_paths']))
  check('no_exact_gate_id_hit',m['task_id'] not in gateids and m['task_id'] not in bodyids)
  check('index_access_gates_preserved',r['source_role']=='UNKNOWN' and r['split']=='UNASSIGNED' and r['actor_visible'] is False and r['trusted_acceptance'] is False and r['training_release']=='BLOCKED')
  evidence=[dict(package=pathlib.Path(z.filename).name,member=p,sha256=sha(z.read(p))) for p in [n,folder+'/public-issue-body.md',folder+'/public-issue.json',folder+'/closure-evidence.json',bodyfile,clfile,clfile.replace('-closures.json','-closures-request.json'),folder+'/base.tar.gz',folder+'/LICENSE']]
  rows.append(dict(task_id=m['task_id'],batch=f'B{batch}',title=m['title'],checks=checks,source_chain_status='VERIFIED_FROM_FIXED_ORIGINALS',closing_pr=m['closing_pr'],merge_commit=m['merge_commit'],base_commit=parent['oid'],base_tree=parent['tree']['oid'],archive_sha256=sha(archive),archive_pax_commit=parent['oid'],tree_scope='UPSTREAM_GRAPHQL_OID_AND_ARCHIVE_COMMIT_BINDING; full git tree not recomputed (no repository test bodies read)',license=dict(status='MIT_NOTICE_AT_EXACT_BASE_VERIFIED',sha256=sha(lic),scope='repository software and associated documentation; preserve copyright and permission notice; does not grant blanket issue-author or dependency licenses'),dependency_declarations=dep,environment_status='NOT_ASSESSED',refs=m['related_refs'],evidence=evidence,source_ready=False,deployable=False,training_approved=False,preserved_gates={k:r[k] for k in ['source_role','split','actor_visible','trusted_acceptance','training_release']},family_clearance='UNKNOWN',unresolved=[]))

write('input-packages.json',inputs)
write('integrity-results.json',ledger_results)
write('gate-provenance-review.json',gate_report)
write('source-review.json',rows)
# Metadata only: include no body values, source contents, PR text or test material.
write('cached-identity-map.json',[dict(number=num,batch=f'B{batch}',member=n,title=node['title'],url=node['url'],closers=node['timelineItems']['nodes']) for num,(batch,n,node) in sorted(raw_nodes.items())])
print(json.dumps(dict(source_candidates=len(rows),all_source_checks_pass=True,batches=ledger_results,gate_sha_mismatches=len(gate_report['claims_mismatch'])),indent=2))
