# Unified B2-B11 Candidate Inputs — Review Only

This immutable bundle gathers the final prompt bytes and machine catalog for the 200 existing B2-B11 identities. It contains 66 selected neutral problem statements and 134 deferred inventory records. The selected set has 57 source-chain `VERIFIED` records and 9 B2 source-chain `PARTIAL` records; B9-B11 source-chain review covered all 60 identities, while only 17 have selected prompts.

All prompt files are copied byte-for-byte from the final reviewed batch ZIPs. The selected prompt text is under `candidate-prompts-review-only/`; provenance, issue references, line quotations, review data, and source ledgers are isolated under `review-only/`. This directory separation is organizational only and is not an OS-level access boundary. Treat the whole archive as review-only.

The nine selected B2 records remain `PARTIAL`: original issue-detail GraphQL and `ClosedEvent.closer` response bytes are `NOT_FOUND_IN_CHECKED_RECORDS`. Normalized closure summaries are not substitutes, and no re-collection is requested. The 57 verified source chains do not imply family clearance, purpose/use approval, old-exposure clearance, actor access, source-role/split assignment, environment validation, training approval, or deployment authorization. Existing family and sealed/dev holds, including `pluggy#140 ↔ pytest#2639`, remain unchanged; no family edge or clearance is added.

Inventory stays at 364 metadata / 344 material / 320 pinned / 85 SOURCE_READY / 0 deployable / 0 training-approved. The 66 prompt candidates are a separate supply count, not added inventory tasks. `source_role=UNKNOWN`, `split=UNASSIGNED`, `actor_visible=false`, `trusted_acceptance=false`, `training_release=BLOCKED`, `deployment_environment=NOT_ASSESSED`; existing holds remain.

## Handoff order

When the live channel is available, first complete the K43 first-item trial and close that actual first item. Then continue toward the existing 400-usable-item target under the established resource budget. This bundle cannot directly start training on 66 items.

## Contents

- `candidate-prompts-review-only/source-chain-verified/`: 57 selected prompts whose source chains were verified within the stated batch review scopes.
- `candidate-prompts-review-only/source-chain-partial/`: 9 selected B2 prompts whose source-chain status remains partial.
- `review-only/catalog.json`: 200 identity records with original package and source anchors, final prompt hashes, effective review comment/manifest hashes, source status, existing gates, and qualification state.
- `review-only/provenance/`: original batch ledgers, separated from candidate prompt text.
- `review-only/handoff.md`: continuation and blocking dependencies.
- `SHA256SUMS.txt`: SHA-256 for every other member.
