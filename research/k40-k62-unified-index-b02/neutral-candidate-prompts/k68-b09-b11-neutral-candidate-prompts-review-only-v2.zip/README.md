## Review-only candidate prompt package

This package contains neutral prompt drafts derived only from the already captured B9–B11 public issue bodies and pinned source metadata. It does not grant actor access, assign a split, clear source families, or approve training use.

Selected: 17. Deferred: 43. See `provenance-ledger.json` for per-item rationale, body line evidence, source identity hashes, edits, and unresolved gates. Original source archives and historical index packages remain separate and are not copied into this prompt bundle.

No PR body/diff/fix, repository test contents, hidden evaluation material, or candidate code was read/run for this task.
